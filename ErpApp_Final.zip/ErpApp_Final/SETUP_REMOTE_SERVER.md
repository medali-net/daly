# 🔧 Configuration pour Serveur Distant (LAPTOP-9MC60CCO)

## 📊 Informations de connexion

```
Serveur SQL Server : LAPTOP-9MC60CCO
Nom de la base de données : ErpDeclarationDB
Authentification : Windows (Integrated Security)
```

---

## ✅ Configuration déjà appliquée

Le fichier `appsettings.json` a été **pré-configuré** avec la chaîne de connexion :

```json
"DefaultConnection": "Server=LAPTOP-9MC60CCO;Database=ErpDeclarationDB;Integrated Security=True;TrustServerCertificate=True;Encrypt=False"
```

---

## 🚀 Démarrage rapide

### 1️⃣ Préparation de la base de données

Avant de lancer l'application, assurez-vous que :

✅ **SQL Server est actif** sur LAPTOP-9MC60CCO  
✅ **La base ErpDeclarationDB existe** (ou sera créée par les migrations)  
✅ **Vous avez accès en Integrated Security (Windows Auth)**

### 2️⃣ Appliquer les migrations EF Core

Ouvrez un terminal dans le dossier `ErpApp` et exécutez :

```bash
# Créer et appliquer les migrations
dotnet ef migrations add InitialCreate
dotnet ef database update
```

**Si erreur de migration :** Exécutez le script SQL manuellement

### 3️⃣ Initialiser les données (optionnel)

Si les migrations ne remplissent pas les données de base, exécutez manuellement :

```bash
# Ouvrir SSMS (SQL Server Management Studio)
# Ou Azure Data Studio

# Exécuter le script :
Database/InitializeDatabase.sql
```

### 4️⃣ Lancer l'application

```bash
dotnet run
```

**URL :** `https://localhost:5001`

---

## 🔐 Compte de test inclus

Après initialisation, le compte suivant est disponible :

```
Login:           admin
Mot de passe :   Admin@123
Rôle :           Administrateur
```

---

## ⚠️ Vérification de la connexion

### Si la connexion échoue :

1. **Vérifier le serveur SQL Server :**
   ```bash
   # Ouvrir Configuration Manager
   # Services SQL Server → Vérifier état
   ```

2. **Tester la connexion dans SSMS :**
   - Ouvrir SQL Server Management Studio
   - Server name : `LAPTOP-9MC60CCO`
   - Authentication : Windows Authentication
   - Se connecter

3. **Vérifier les permissions :**
   - L'utilisateur Windows doit avoir accès en lecture/écriture
   - Ou créer un user SQL Server dédié

### Variantes de connexion :

Si Integrated Security ne fonctionne pas, modifier `appsettings.json` :

**Avec SQL Server Authentication :**
```json
"DefaultConnection": "Server=LAPTOP-9MC60CCO;Database=ErpDeclarationDB;User Id=sa;Password=YourPassword;TrustServerCertificate=True"
```

**Sur un port spécifique :**
```json
"DefaultConnection": "Server=LAPTOP-9MC60CCO,1433;Database=ErpDeclarationDB;Integrated Security=True;TrustServerCertificate=True"
```

---

## 📁 Fichiers importants

```
appsettings.json              ← Connection string PRÉ-CONFIGURÉE
Database/InitializeDatabase.sql ← Script SQL de seed data
Database/setup.sql            ← Script SQL complet alternatif
```

---

## 🔄 Première utilisation

```
1. Serveur LAPTOP-9MC60CCO est actif ✅
2. Base ErpDeclarationDB existe ✅
3. Migrations appliquées ✅
4. Données de base chargées ✅
5. Lancer l'app ✅
6. Login: admin / Admin@123 ✅
```

---

## 🛠️ Maintenance

### Vérifier l'état de la connexion :

```bash
# Affiche les infos de connexion
dotnet ef dbcontext info
```

### Voir les migrations appliquées :

```bash
dotnet ef migrations list
```

### Réinitialiser la base (dangereux !) :

```bash
# Supprimer toutes les données
dotnet ef database drop -f

# Recréer de zéro
dotnet ef database update
```

---

## 📞 Dépannage

### Erreur : "Cannot open database"

**Cause :** La base n'existe pas ou le serveur est inaccessible

**Solutions :**
```bash
# 1. Vérifier le serveur est accessible
ping LAPTOP-9MC60CCO

# 2. Vérifier SQL Server est actif
# Ouvrir Services Windows → SQL Server (MSSQLSERVER)

# 3. Créer la base manuellement :
# Ouvrir SSMS → New Database → ErpDeclarationDB
```

### Erreur : "Login failed for user"

**Cause :** Pas d'accès Integrated Security

**Solutions :**
```bash
# 1. Vérifier Windows Auth est activée dans SQL Server
# 2. Ou utiliser SQL Server Auth avec user/password
# 3. Modifier appsettings.json

# Exemple avec sa :
"DefaultConnection": "Server=LAPTOP-9MC60CCO;Database=ErpDeclarationDB;User Id=sa;Password=YourSAPassword;TrustServerCertificate=True"
```

### Erreur : "Timeout"

**Cause :** Réseau lent ou pare-feu bloque SQL Server

**Solutions :**
```bash
# 1. Vérifier pare-feu Windows (ouvert port 1433)
# 2. Vérifier réseau (WiFi/Ethernet)
# 3. Augmenter timeout :

"DefaultConnection": "Server=LAPTOP-9MC60CCO;Database=ErpDeclarationDB;Integrated Security=True;TrustServerCertificate=True;Connection Timeout=30"
```

---

## ✨ Application prête !

L'application est **100% configurée** pour se connecter à :

```
Server   : LAPTOP-9MC60CCO
Database : ErpDeclarationDB
Auth     : Windows (Integrated Security)
Admin    : admin / Admin@123
```

**Il suffit de :**
1. ✅ Vérifier SQL Server actif
2. ✅ Appliquer les migrations (`dotnet ef database update`)
3. ✅ Lancer l'app (`dotnet run`)
4. ✅ Accéder à `https://localhost:5001`

---

**Configuration v2.5 — ERP Déclaration © 2026**
