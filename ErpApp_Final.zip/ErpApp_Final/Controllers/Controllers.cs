using Microsoft.AspNetCore.Mvc;
using BC = BCrypt.Net.BCrypt;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using ErpApp.Models;
using ErpApp.Services;

namespace ErpApp.Controllers
{
    // =====================================================================
    // AUTH
    // =====================================================================
    public class AuthController : Controller
    {
        private readonly IUserService _users;
        public AuthController(IUserService users) { _users = users; }

        [HttpGet] public IActionResult Login() { if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Home"); return View(); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);
            var valid = await _users.ValidatePasswordAsync(model.Login, model.Password);
            if (!valid) { ModelState.AddModelError("", "Login ou mot de passe incorrect."); return View(model); }
            var user = await _users.GetByLoginAsync(model.Login);
            var claims = new List<Claim> {
                new(ClaimTypes.NameIdentifier, user!.Id.ToString()),
                new(ClaimTypes.Name, user.Login),
                new(ClaimTypes.Email, user.Email),
                new(ClaimTypes.Role, user.Role?.LibelleFr ?? "")
            };
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme)));
            user.LastLoginAt = DateTime.Now;
            await _users.UpdateAsync(user);
            return RedirectToAction("Index", "Home");
        }

        public async Task<IActionResult> Logout() { await HttpContext.SignOutAsync(); return RedirectToAction("Login"); }
    }

    // =====================================================================
    // HOME / DASHBOARD
    // =====================================================================
    [Authorize]
    public class HomeController : Controller
    {
        private readonly IDashboardService _dash;
        public HomeController(IDashboardService dash) { _dash = dash; }
        public async Task<IActionResult> Index() { return View(await _dash.GetAsync()); }
    }

    // =====================================================================
    // GOUVERNORATS
    // =====================================================================
    [Authorize]
    public class GouvernoratsController : Controller
    {
        private readonly IGouvernoratService _svc;
        public GouvernoratsController(IGouvernoratService svc) { _svc = svc; }

        public async Task<IActionResult> Index() => View(await _svc.GetAllAsync());

        public IActionResult Create() => View(new Gouvernorat());

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Gouvernorat e)
        {
            if (await _svc.ExistsAsync(e.NomFr, null)) ModelState.AddModelError("NomFr", "Ce nom existe déjà.");
            if (!ModelState.IsValid) return View(e);
            await _svc.CreateAsync(e);
            TempData["Success"] = $"Gouvernorat « {e.NomFr} » créé.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id) { var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound(); return View(e); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Gouvernorat e)
        {
            if (id != e.Id) return BadRequest();
            if (await _svc.ExistsAsync(e.NomFr, id)) ModelState.AddModelError("NomFr", "Ce nom existe déjà.");
            if (!ModelState.IsValid) return View(e);
            await _svc.UpdateAsync(e);
            TempData["Success"] = "Gouvernorat modifié.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            await _svc.DeleteAsync(id);
            TempData["Success"] = "Gouvernorat supprimé.";
            return RedirectToAction(nameof(Index));
        }
    }

    // =====================================================================
    // DELEGATIONS
    // =====================================================================
    [Authorize]
    public class DelegationsController : Controller
    {
        private readonly IDelegationService _svc;
        private readonly IGouvernoratService _govSvc;
        public DelegationsController(IDelegationService svc, IGouvernoratService govSvc) { _svc = svc; _govSvc = govSvc; }

        public async Task<IActionResult> Index(int? gouvernoratId)
        {
            ViewBag.GouvernoratId = gouvernoratId;
            ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr", gouvernoratId);
            return View(await _svc.GetAllAsync(gouvernoratId));
        }

        public async Task<IActionResult> Create() { ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr"); return View(new Delegation()); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Delegation e)
        {
            if (!ModelState.IsValid) { ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr", e.GouvernoratId); return View(e); }
            await _svc.CreateAsync(e);
            TempData["Success"] = $"Délégation « {e.NomFr} » créée.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id) { var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound(); ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr", e.GouvernoratId); return View(e); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Delegation e)
        {
            if (id != e.Id) return BadRequest();
            if (!ModelState.IsValid) { ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr", e.GouvernoratId); return View(e); }
            await _svc.UpdateAsync(e);
            TempData["Success"] = "Délégation modifiée.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id) { await _svc.DeleteAsync(id); TempData["Success"] = "Délégation supprimée."; return RedirectToAction(nameof(Index)); }

        [HttpGet]
        public async Task<IActionResult> GetByGouvernorat(int gouvernoratId)
        {
            var list = await _svc.GetAllAsync(gouvernoratId);
            return Json(list.Select(d => new { d.Id, text = $"{d.NomFr} ({d.CodePostal})" }));
        }
    }

    // =====================================================================
    // ADMINISTRATIONS
    // =====================================================================
    [Authorize]
    public class AdministrationsController : Controller
    {
        private readonly IAdministrationService _svc;
        private readonly IGouvernoratService _govSvc;
        public AdministrationsController(IAdministrationService svc, IGouvernoratService govSvc) { _svc = svc; _govSvc = govSvc; }

        public async Task<IActionResult> Index() => View(await _svc.GetAllAsync());

        public async Task<IActionResult> Create() { ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr"); return View(new Administration()); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Administration e)
        {
            if (await _svc.CodeExistsAsync(e.CodeAdministration, null)) ModelState.AddModelError("CodeAdministration", "Ce code existe déjà.");
            if (!ModelState.IsValid) { ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr", e.GouvernoratId); return View(e); }
            await _svc.CreateAsync(e);
            TempData["Success"] = $"Administration « {e.NomFr} » créée.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id) { var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound(); ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr", e.GouvernoratId); return View(e); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Administration e)
        {
            if (id != e.Id) return BadRequest();
            if (await _svc.CodeExistsAsync(e.CodeAdministration, id)) ModelState.AddModelError("CodeAdministration", "Ce code existe déjà.");
            if (!ModelState.IsValid) { ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr", e.GouvernoratId); return View(e); }
            await _svc.UpdateAsync(e);
            TempData["Success"] = "Administration modifiée.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id) { await _svc.DeleteAsync(id); TempData["Success"] = "Administration supprimée."; return RedirectToAction(nameof(Index)); }
    }

    // =====================================================================
    // ROLES
    // =====================================================================
    [Authorize]
    public class RolesController : Controller
    {
        private readonly IRoleService _svc;
        public RolesController(IRoleService svc) { _svc = svc; }
        public async Task<IActionResult> Index() => View(await _svc.GetAllAsync());
        public IActionResult Create() => View(new Role());
        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Role e) { if (!ModelState.IsValid) return View(e); await _svc.CreateAsync(e); TempData["Success"] = $"Rôle « {e.LibelleFr} » créé."; return RedirectToAction(nameof(Index)); }
        public async Task<IActionResult> Edit(int id) { var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound(); return View(e); }
        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Role e) { if (id != e.Id) return BadRequest(); if (!ModelState.IsValid) return View(e); await _svc.UpdateAsync(e); TempData["Success"] = "Rôle modifié."; return RedirectToAction(nameof(Index)); }
        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id) { await _svc.DeleteAsync(id); TempData["Success"] = "Rôle supprimé."; return RedirectToAction(nameof(Index)); }
    }

    // =====================================================================
    // USERS
    // =====================================================================
    [Authorize]
    public class UsersController : Controller
    {
        private readonly IUserService _svc;
        private readonly IRoleService _roleSvc;
        public UsersController(IUserService svc, IRoleService roleSvc) { _svc = svc; _roleSvc = roleSvc; }

        public async Task<IActionResult> Index() => View(await _svc.GetAllAsync());

        public async Task<IActionResult> Create() { ViewBag.Roles = new SelectList(await _roleSvc.GetAllAsync(), "Id", "LibelleFr"); return View(new User()); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(User e)
        {
            if (await _svc.LoginExistsAsync(e.Login, null)) ModelState.AddModelError("Login", "Ce login existe déjà.");
            if (string.IsNullOrEmpty(e.Password)) ModelState.AddModelError("Password", "Le mot de passe est obligatoire.");
            ModelState.Remove("PasswordHash");
            if (!ModelState.IsValid) { ViewBag.Roles = new SelectList(await _roleSvc.GetAllAsync(), "Id", "LibelleFr", e.RoleId); return View(e); }
            await _svc.CreateAsync(e, e.Password!);
            TempData["Success"] = $"Utilisateur « {e.Login} » créé.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id) { var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound(); ViewBag.Roles = new SelectList(await _roleSvc.GetAllAsync(), "Id", "LibelleFr", e.RoleId); return View(e); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, User e)
        {
            if (id != e.Id) return BadRequest();
            ModelState.Remove("PasswordHash"); ModelState.Remove("Password"); ModelState.Remove("ConfirmPassword");
            if (!ModelState.IsValid) { ViewBag.Roles = new SelectList(await _roleSvc.GetAllAsync(), "Id", "LibelleFr", e.RoleId); return View(e); }
            var existing = await _svc.GetByIdAsync(id);
            if (existing == null) return NotFound();
            existing.Email = e.Email; existing.RoleId = e.RoleId; existing.IsActive = e.IsActive;
            if (!string.IsNullOrEmpty(e.Password)) existing.PasswordHash = BC.HashPassword(e.Password);
            await _svc.UpdateAsync(existing);
            TempData["Success"] = "Utilisateur modifié.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var me = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");
            if (id == me) { TempData["Error"] = "Vous ne pouvez pas supprimer votre propre compte."; return RedirectToAction(nameof(Index)); }
            await _svc.DeleteAsync(id);
            TempData["Success"] = "Utilisateur supprimé.";
            return RedirectToAction(nameof(Index));
        }
    }

    // =====================================================================
    // AGENTS
    // =====================================================================
    [Authorize]
    public class AgentsController : Controller
    {
        private readonly IAgentService _svc;
        private readonly IAdministrationService _admSvc;
        private readonly IUserService _userSvc;
        public AgentsController(IAgentService svc, IAdministrationService admSvc, IUserService userSvc) { _svc = svc; _admSvc = admSvc; _userSvc = userSvc; }

        public async Task<IActionResult> Index(string? search) { ViewBag.Search = search; return View(await _svc.GetAllAsync(search)); }

        public async Task<IActionResult> Details(int id) { var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound(); return View(e); }

        public async Task<IActionResult> Create() { await SetViewBag(); return View(new Agent()); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Agent e)
        {
            if (await _svc.MatriculeExistsAsync(e.Matricule, null)) ModelState.AddModelError("Matricule", "Ce matricule existe déjà.");
            if (!ModelState.IsValid) { await SetViewBag(e.AdministrationId, e.UserId); return View(e); }
            await _svc.CreateAsync(e);
            TempData["Success"] = $"Agent {e.Prenom} {e.Nom} créé.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id) { var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound(); await SetViewBag(e.AdministrationId, e.UserId); return View(e); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Agent e)
        {
            if (id != e.Id) return BadRequest();
            if (await _svc.MatriculeExistsAsync(e.Matricule, id)) ModelState.AddModelError("Matricule", "Ce matricule existe déjà.");
            if (!ModelState.IsValid) { await SetViewBag(e.AdministrationId, e.UserId); return View(e); }
            await _svc.UpdateAsync(e);
            TempData["Success"] = "Agent modifié.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id) { await _svc.DeleteAsync(id); TempData["Success"] = "Agent supprimé."; return RedirectToAction(nameof(Index)); }

        private async Task SetViewBag(int? admId = null, int? userId = null)
        {
            ViewBag.Administrations = new SelectList(await _admSvc.GetAllAsync(), "Id", "NomFr", admId);
            ViewBag.Users = new SelectList(await _userSvc.GetAllAsync(), "Id", "Login", userId);
        }
    }

    // =====================================================================
    // CLIENTS
    // =====================================================================
    [Authorize]
    public class ClientsController : Controller
    {
        private readonly IClientService _svc;
        private readonly IGenreService _genreSvc;
        public ClientsController(IClientService svc, IGenreService genreSvc) { _svc = svc; _genreSvc = genreSvc; }

        public async Task<IActionResult> Index(string? search, int? genreId)
        {
            ViewBag.Search = search; ViewBag.GenreId = genreId;
            ViewBag.Genres = new SelectList(await _genreSvc.GetAllAsync(), "Id", "LibelleFr", genreId);
            return View(await _svc.GetAllAsync(search, genreId));
        }

        public async Task<IActionResult> Details(int id) { var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound(); return View(e); }

        public async Task<IActionResult> Create() { ViewBag.Genres = new SelectList(await _genreSvc.GetAllAsync(), "Id", "LibelleFr"); return View(new Client()); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Client e)
        {
            if (await _svc.CINExistsAsync(e.CIN, null)) ModelState.AddModelError("CIN", "Ce CIN existe déjà.");
            if (!ModelState.IsValid) { ViewBag.Genres = new SelectList(await _genreSvc.GetAllAsync(), "Id", "LibelleFr", e.GenreId); return View(e); }
            e.CreatedById = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "1");
            await _svc.CreateAsync(e);
            TempData["Success"] = $"Client {e.Prenom} {e.Nom} créé.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id) { var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound(); ViewBag.Genres = new SelectList(await _genreSvc.GetAllAsync(), "Id", "LibelleFr", e.GenreId); return View(e); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Client e)
        {
            if (id != e.Id) return BadRequest();
            if (await _svc.CINExistsAsync(e.CIN, id)) ModelState.AddModelError("CIN", "Ce CIN existe déjà.");
            if (!ModelState.IsValid) { ViewBag.Genres = new SelectList(await _genreSvc.GetAllAsync(), "Id", "LibelleFr", e.GenreId); return View(e); }
            e.UpdatedById = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "1");
            await _svc.UpdateAsync(e);
            TempData["Success"] = "Client modifié.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "1");
            await _svc.SoftDeleteAsync(id, userId);
            TempData["Success"] = "Client supprimé.";
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> CheckCIN(string cin, int? id) => Json(!await _svc.CINExistsAsync(cin, id));
    }

    // =====================================================================
    // ACTIVITES
    // =====================================================================
    [Authorize]
    public class ActivitesController : Controller
    {
        private readonly IActiviteService _svc;
        public ActivitesController(IActiviteService svc) { _svc = svc; }
        public async Task<IActionResult> Index(string? search) { ViewBag.Search = search; return View(await _svc.GetAllAsync(search)); }
        public IActionResult Create() => View(new Activite());
        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Activite e) { if (await _svc.CodeExistsAsync(e.CodeNACE_Ape, null)) ModelState.AddModelError("CodeNACE_Ape", "Ce code existe déjà."); if (!ModelState.IsValid) return View(e); await _svc.CreateAsync(e); TempData["Success"] = $"Activité « {e.LibelleFr} » créée."; return RedirectToAction(nameof(Index)); }
        public async Task<IActionResult> Edit(int id) { var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound(); return View(e); }
        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Activite e) { if (id != e.Id) return BadRequest(); if (await _svc.CodeExistsAsync(e.CodeNACE_Ape, id)) ModelState.AddModelError("CodeNACE_Ape", "Ce code existe déjà."); if (!ModelState.IsValid) return View(e); await _svc.UpdateAsync(e); TempData["Success"] = "Activité modifiée."; return RedirectToAction(nameof(Index)); }
        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id) { await _svc.DeleteAsync(id); TempData["Success"] = "Activité supprimée."; return RedirectToAction(nameof(Index)); }
    }

    // =====================================================================
    // PROJETS
    // =====================================================================
    [Authorize]
    public class ProjetsController : Controller
    {
        private readonly IProjetService _svc;
        private readonly IClientService _clientSvc;
        private readonly IGouvernoratService _govSvc;
        private readonly ITypeProjetService _tpSvc;
        private readonly ITypeCreateurService _tcSvc;
        private readonly IActiviteService _actSvc;
        private readonly ILocalService _localSvc;
        private readonly IDelegationService _delSvc;
        private readonly ITypeLocalService _tlSvc;

        public ProjetsController(IProjetService svc, IClientService clientSvc, IGouvernoratService govSvc,
            ITypeProjetService tpSvc, ITypeCreateurService tcSvc, IActiviteService actSvc,
            ILocalService localSvc, IDelegationService delSvc, ITypeLocalService tlSvc)
        {
            _svc = svc; _clientSvc = clientSvc; _govSvc = govSvc;
            _tpSvc = tpSvc; _tcSvc = tcSvc; _actSvc = actSvc;
            _localSvc = localSvc; _delSvc = delSvc; _tlSvc = tlSvc;
        }

        public async Task<IActionResult> Index(string? search, int? typeId, bool? actif)
        {
            ViewBag.Search = search; ViewBag.TypeId = typeId; ViewBag.Actif = actif;
            ViewBag.TypeProjets = new SelectList(await _tpSvc.GetAllAsync(), "Id", "LibelleFr", typeId);
            return View(await _svc.GetAllAsync(search, typeId, actif));
        }

        public async Task<IActionResult> Details(int id)
        {
            var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound();
            ViewBag.Historique = await _svc.GetHistoriqueAsync(id);
            return View(e);
        }

        public async Task<IActionResult> Create() { await SetViewBag(); return View(new ProjetViewModel()); }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProjetViewModel vm)
        {
            if (await _svc.MFExistsAsync(vm.Projet.MatriculeFiscale, null)) ModelState.AddModelError("Projet.MatriculeFiscale", "Cette matricule fiscale existe déjà.");
            if (await _svc.RNEExistsAsync(vm.Projet.RNE, null)) ModelState.AddModelError("Projet.RNE", "Ce RNE existe déjà.");
            if (!ModelState.IsValid) { await SetViewBag(); return View(vm); }
            vm.Projet.CreatedById = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "1");
            var id = await _svc.CreateAsync(vm.Projet, vm.ActiviteIds, vm.PrincipaleActiviteId);
            TempData["Success"] = $"Projet créé avec le numéro PRJ-{DateTime.Now.Year}-{id:D6}.";
            return RedirectToAction(nameof(Details), new { id });
        }

        public async Task<IActionResult> Edit(int id)
        {
            var e = await _svc.GetByIdAsync(id); if (e == null) return NotFound();
            var vm = new ProjetViewModel {
                Projet = e,
                ActiviteIds = e.ProjetActivites.Select(pa => pa.ActiviteId).ToList(),
                PrincipaleActiviteId = e.ProjetActivites.FirstOrDefault(pa => pa.EstPrincipale)?.ActiviteId
            };
            await SetViewBag(e);
            return View(vm);
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ProjetViewModel vm)
        {
            if (id != vm.Projet.Id) return BadRequest();
            if (await _svc.MFExistsAsync(vm.Projet.MatriculeFiscale, id)) ModelState.AddModelError("Projet.MatriculeFiscale", "Cette matricule fiscale existe déjà.");
            if (await _svc.RNEExistsAsync(vm.Projet.RNE, id)) ModelState.AddModelError("Projet.RNE", "Ce RNE existe déjà.");
            if (!ModelState.IsValid) { await SetViewBag(); return View(vm); }
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "1");
            await _svc.UpdateAsync(vm.Projet, vm.ActiviteIds, vm.PrincipaleActiviteId, userId);
            TempData["Success"] = "Projet modifié.";
            return RedirectToAction(nameof(Details), new { id });
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "1");
            await _svc.SoftDeleteAsync(id, userId);
            TempData["Success"] = "Projet supprimé.";
            return RedirectToAction(nameof(Index));
        }

        // LOCAUX
        [HttpGet]
        public async Task<IActionResult> AddLocal(int projetId)
        {
            ViewBag.ProjetId = projetId;
            ViewBag.TypeLocaux = new SelectList(await _tlSvc.GetAllAsync(), "Id", "LibelleFr");
            ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr");
            ViewBag.Delegations = new SelectList(Enumerable.Empty<object>(), "Id", "NomFr");
            return View(new Local { ProjetId = projetId });
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> AddLocal(Local e)
        {
            if (!ModelState.IsValid) {
                ViewBag.ProjetId = e.ProjetId;
                ViewBag.TypeLocaux = new SelectList(await _tlSvc.GetAllAsync(), "Id", "LibelleFr", e.TypeLocalId);
                ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr");
                ViewBag.Delegations = new SelectList(await _delSvc.GetAllAsync(null), "Id", "NomFr", e.DelegationId);
                return View(e);
            }
            await _localSvc.CreateAsync(e);
            TempData["Success"] = "Local ajouté.";
            return RedirectToAction(nameof(Details), new { id = e.ProjetId });
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteLocal(int id, int projetId)
        {
            await _localSvc.DeleteAsync(id);
            TempData["Success"] = "Local supprimé.";
            return RedirectToAction(nameof(Details), new { id = projetId });
        }

        private async Task SetViewBag(Projet? p = null)
        {
            ViewBag.Clients = new SelectList(await _clientSvc.GetAllAsync(), "Id", "NomComplet", p?.ClientId);
            ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr", p?.GouvernoratId);
            ViewBag.TypeProjets = new SelectList(await _tpSvc.GetAllAsync(), "Id", "LibelleFr", p?.TypeProjetId);
            ViewBag.TypeCreateurs = new SelectList(await _tcSvc.GetAllAsync(), "Id", "LibelleFr", p?.TypeCreateurId);
            ViewBag.Activites = await _actSvc.GetAllAsync();
        }
    }
}
