using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using ErpApp.Models;
using ErpApp.Services;

namespace ErpApp.Controllers
{
    // =====================================================================
    // AUTH CITOYEN (Register / ForgotPassword / ResetPassword)
    // =====================================================================
    public class CitoyenAuthController : Controller
    {
        private readonly ICitoyenService _svc;
        public CitoyenAuthController(ICitoyenService svc) { _svc = svc; }

        // ── REGISTER ──────────────────────────────────────────────────────
        [HttpGet]
        public IActionResult Register() => View(new RegisterCitoyenViewModel());

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterCitoyenViewModel vm)
        {
            if (await _svc.LoginExistsAsync(vm.Login))
                ModelState.AddModelError("Login", "Ce login est déjà utilisé.");
            if (await _svc.EmailExistsAsync(vm.Email))
                ModelState.AddModelError("Email", "Cet email est déjà utilisé.");
            if (await _svc.CINExistsAsync(vm.CIN))
                ModelState.AddModelError("CIN", "Ce CIN est déjà enregistré.");

            if (!ModelState.IsValid) return View(vm);

            var citoyen = await _svc.RegisterAsync(vm);
            await SignInCitoyenAsync(citoyen);
            TempData["Success"] = $"Bienvenue {citoyen.Prenom} ! Votre compte a été créé avec succès.";
            return RedirectToAction("Index", "CitoyenEspace");
        }

        // ── LOGIN (utilisé depuis Auth/Login via onglet citoyen) ──────────
        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string login, string password, string returnUrl = "/CitoyenEspace")
        {
            if (!await _svc.ValidatePasswordAsync(login, password))
            {
                TempData["CitoyenError"] = "Login ou mot de passe incorrect.";
                return RedirectToAction("Login", "Auth", new { tab = "citoyen" });
            }
            var citoyen = await _svc.GetByLoginAsync(login);
            citoyen!.LastLoginAt = DateTime.Now;
            await _svc.UpdateAsync(citoyen);
            await SignInCitoyenAsync(citoyen);
            return LocalRedirect(returnUrl);
        }

        // ── FORGOT PASSWORD ───────────────────────────────────────────────
        [HttpGet]
        public IActionResult ForgotPassword() => View(new ForgotPasswordViewModel());

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var citoyen = await _svc.FindForResetAsync(vm.LoginOrEmail, vm.CIN);
            if (citoyen == null)
            {
                ModelState.AddModelError("", "Aucun compte trouvé avec ces informations.");
                return View(vm);
            }

            var token = await _svc.GenerateResetTokenAsync(citoyen);
            // Dans un vrai projet, envoyer le token par email. Ici on redirige directement.
            TempData["ResetToken"] = token;
            TempData["Info"] = $"Identité vérifiée pour {citoyen.Prenom} {citoyen.Nom}.";
            return RedirectToAction("ResetPassword", new { token });
        }

        // ── RESET PASSWORD ────────────────────────────────────────────────
        [HttpGet]
        public async Task<IActionResult> ResetPassword(string token)
        {
            var citoyen = await _svc.GetByResetTokenAsync(token);
            if (citoyen == null)
            {
                TempData["Error"] = "Lien invalide ou expiré.";
                return RedirectToAction("Login", "Auth");
            }
            return View(new ResetPasswordViewModel { Token = token });
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> ResetPassword(ResetPasswordViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var ok = await _svc.ResetPasswordAsync(vm.Token, vm.NewPassword);
            if (!ok)
            {
                ModelState.AddModelError("", "Lien invalide ou expiré.");
                return View(vm);
            }
            TempData["Success"] = "Mot de passe réinitialisé avec succès. Vous pouvez vous connecter.";
            return RedirectToAction("Login", "Auth");
        }

        // ── LOGOUT CITOYEN ────────────────────────────────────────────────
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Auth");
        }

        // ── HELPER ───────────────────────────────────────────────────────
        private async Task SignInCitoyenAsync(Citoyen citoyen)
        {
            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, citoyen.Id.ToString()),
                new(ClaimTypes.Name, citoyen.Login),
                new(ClaimTypes.Email, citoyen.Email),
                new(ClaimTypes.Role, "Citoyen"),
                new("FullName", citoyen.NomComplet)
            };
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme)));
        }
    }

    // =====================================================================
    // ESPACE CITOYEN (Dashboard + Projets personnels)
    // =====================================================================
    [Authorize(Roles = "Citoyen")]
    public class CitoyenEspaceController : Controller
    {
        private readonly ICitoyenService _svc;
        private readonly IActiviteService _actSvc;
        private readonly ITypeProjetService _tpSvc;
        private readonly ITypeCreateurService _tcSvc;
        private readonly IGouvernoratService _govSvc;

        public CitoyenEspaceController(ICitoyenService svc, IActiviteService actSvc,
            ITypeProjetService tpSvc, ITypeCreateurService tcSvc, IGouvernoratService govSvc)
        {
            _svc = svc; _actSvc = actSvc; _tpSvc = tpSvc; _tcSvc = tcSvc; _govSvc = govSvc;
        }

        private int CitoyenId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");

        // ── DASHBOARD ─────────────────────────────────────────────────────
        public async Task<IActionResult> Index()
        {
            var vm = await _svc.GetDashboardAsync(CitoyenId);
            return View(vm);
        }

        // ── PROFIL / CHANGER MOT DE PASSE ─────────────────────────────────
        [HttpGet]
        public async Task<IActionResult> Profil()
        {
            var c = await _svc.GetByIdAsync(CitoyenId);
            if (c == null) return NotFound();
            return View(c);
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangerMotDePasse(string ancienMdp, string nouveauMdp, string confirmerMdp)
        {
            var c = await _svc.GetByIdAsync(CitoyenId);
            if (c == null) return NotFound();

            if (!BCrypt.Net.BCrypt.Verify(ancienMdp, c.PasswordHash))
            {
                TempData["Error"] = "L'ancien mot de passe est incorrect.";
                return RedirectToAction("Profil");
            }
            if (nouveauMdp != confirmerMdp)
            {
                TempData["Error"] = "Les nouveaux mots de passe ne correspondent pas.";
                return RedirectToAction("Profil");
            }
            if (nouveauMdp.Length < 6)
            {
                TempData["Error"] = "Le mot de passe doit contenir au moins 6 caractères.";
                return RedirectToAction("Profil");
            }

            c.PasswordHash = BCrypt.Net.BCrypt.HashPassword(nouveauMdp);
            await _svc.UpdateAsync(c);
            TempData["Success"] = "Mot de passe modifié avec succès.";
            return RedirectToAction("Profil");
        }

        // ── PROJETS LIST ──────────────────────────────────────────────────
        public async Task<IActionResult> MesProjets()
        {
            var projets = await _svc.GetProjetsAsync(CitoyenId);
            return View(projets);
        }

        // ── PROJET DETAILS ────────────────────────────────────────────────
        public async Task<IActionResult> ProjetDetails(int id)
        {
            var p = await _svc.GetProjetByIdAsync(id, CitoyenId);
            if (p == null) return NotFound();
            return View(p);
        }

        // ── PROJET CREATE ─────────────────────────────────────────────────
        [HttpGet]
        public async Task<IActionResult> NouveauProjet()
        {
            await SetViewBag();
            return View(new CitoyenProjetViewModel());
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> NouveauProjet(CitoyenProjetViewModel vm)
        {
            if (!ModelState.IsValid) { await SetViewBag(); return View(vm); }

            vm.Projet.CitoyenId = CitoyenId;
            await _svc.CreateProjetAsync(vm.Projet, vm.ActiviteIds, vm.PrincipaleActiviteId);
            TempData["Success"] = $"Projet « {vm.Projet.NomProjet} » soumis avec succès. Il est en attente de validation.";
            return RedirectToAction("MesProjets");
        }

        // ── PROJET EDIT (seulement si EnAttente) ──────────────────────────
        [HttpGet]
        public async Task<IActionResult> ModifierProjet(int id)
        {
            var p = await _svc.GetProjetByIdAsync(id, CitoyenId);
            if (p == null) return NotFound();
            if (p.Statut != "EnAttente")
            {
                TempData["Error"] = "Seuls les projets en attente peuvent être modifiés.";
                return RedirectToAction("MesProjets");
            }
            await SetViewBag(p);
            var vm = new CitoyenProjetViewModel
            {
                Projet = p,
                ActiviteIds = p.Activites.Select(a => a.ActiviteId).ToList(),
                PrincipaleActiviteId = p.Activites.FirstOrDefault(a => a.EstPrincipale)?.ActiviteId
            };
            return View(vm);
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> ModifierProjet(int id, CitoyenProjetViewModel vm)
        {
            if (id != vm.Projet.Id) return BadRequest();
            var existing = await _svc.GetProjetByIdAsync(id, CitoyenId);
            if (existing == null || existing.Statut != "EnAttente") return Forbid();

            if (!ModelState.IsValid) { await SetViewBag(); return View(vm); }

            vm.Projet.CitoyenId = CitoyenId;
            vm.Projet.Statut = "EnAttente";
            await _svc.UpdateProjetAsync(vm.Projet, vm.ActiviteIds, vm.PrincipaleActiviteId);
            TempData["Success"] = "Projet modifié.";
            return RedirectToAction("MesProjets");
        }

        // ── PROJET DELETE ─────────────────────────────────────────────────
        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> SupprimerProjet(int id)
        {
            var ok = await _svc.DeleteProjetAsync(id, CitoyenId);
            if (!ok)
                TempData["Error"] = "Impossible de supprimer ce projet (déjà validé ou introuvable).";
            else
                TempData["Success"] = "Projet supprimé.";
            return RedirectToAction("MesProjets");
        }

        private async Task SetViewBag(CitoyenProjet? p = null)
        {
            ViewBag.TypeProjets = new SelectList(await _tpSvc.GetAllAsync(), "Id", "LibelleFr", p?.TypeProjetId);
            ViewBag.TypeCreateurs = new SelectList(await _tcSvc.GetAllAsync(), "Id", "LibelleFr", p?.TypeCreateurId);
            ViewBag.Gouvernorats = new SelectList(await _govSvc.GetAllAsync(), "Id", "NomFr", p?.GouvernoratId);
            ViewBag.Activites = await _actSvc.GetAllAsync();
        }
    }
}
