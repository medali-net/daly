# 🏛️ **ERP DÉCLARATION v2.5 — SOLUTION COMPLÈTE**

> **Système de gestion des déclarations de projets en Tunisie — Bilingue FR/عربي**  
> **ASP.NET Core 8 MVC | SQL Server | EF Core | BCrypt | RBAC**

---

## 📋 TABLE DES MATIÈRES

1. [Démarrage rapide](#-démarrage-rapide)
2. [Architecture](#-architecture)
3. [Fonctionnalités Agent/Admin](#-fonctionnalités-agentadmin)
4. [Fonctionnalités Citoyen](#-fonctionnalités-citoyen)
5. [Base de données](#-base-de-données)
6. [Structure du projet](#-structure-du-projet)
7. [Configuration](#-configuration)
8. [Sécurité](#-sécurité)
9. [Compte de test](#-compte-de-test)

---

## 🚀 Démarrage rapide

### Prérequis
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- SQL Server 2016+ / LocalDB / SQL Server Express
- Visual Studio 2022 / VS Code / Rider

### Installation en 3 étapes

```bash
# 1. Extraire le ZIP et accéder au dossier
cd ErpApp

# 2. Créer et appliquer les migrations
dotnet ef migrations add InitialCreate
dotnet ef database update

# 3. Lancer l'application
dotnet run
```

**URL :** `https://localhost:5001`

---

## 🏗️ Architecture

### Stack technique
- **Framework :** ASP.NET Core 8 MVC
- **Base de données :** SQL Server / LocalDB
- **ORM :** Entity Framework Core 8
- **Authentification :** Cookie-based (ASP.NET Core)
- **Hachage MDP :** BCrypt.Net-Next 4.0.3
- **Frontend :** Razor Views + Custom CSS + Vanilla JS

### Ports de communication
- Localhost: `https://localhost:5001`
- SQL Server: `(localdb)\mssqllocaldb` ou configurable

---

## 👔 Fonctionnalités Agent/Admin

### Authentification
- **Login :** `admin` / `Admin@123` (par défaut)
- Gestion des utilisateurs avec rôles RBAC
- Hachage BCrypt des mots de passe
- Verrouillage de compte après 5 tentatives

### Modules de gestion

| Module | CRUD | Notes |
|--------|------|-------|
| **🗺️ Gouvernorats** | ✅ | Bilingues FR/AR |
| **🚩 Délégations** | ✅ | Cascade gouvernorat → délégation AJAX |
| **🏛️ Administrations** | ✅ | Par gouvernorat, code unique |
| **👤 Agents** | ✅ | Liés à une administration |
| **💼 Clients** | ✅ | Soft delete, CIN unique, filtrage genre |
| **👥 Utilisateurs** | ✅ | Gestion rôles, vérrouillage |
| **⚙️ Rôles** | ✅ | Admin, Agent, Consultant (bilingues) |
| **🏗️ Types** | ✅ | Projets, Créateurs, Locaux (bilingues) |
| **🔧 Activités NACE** | ✅ | Codes + libellés bilingues |
| **📁 Projets** | ✅ | Numérotation auto, soft delete, historique |

### Fonctionnalités avancées
- **Dashboard** : Statistiques temps réel, répartition par type/gouvernorat
- **Projets** : 
  - Numérotation automatique `PRJ-YYYY-XXXXXX`
  - Liaison Many-to-Many avec activités NACE/APE
  - Gestion des locaux (adresse, surface, délégation)
  - Historique complet des modifications (trigger SQL)
  - Soft delete (données préservées)
- **Recherche & filtrage** : Partout dans l'application
- **Cascade dynamique** : Gouvernorat → Délégation en AJAX
- **Fiches détaillées** : Onglets Info/Activités/Locaux/Historique

---

## 👤 Fonctionnalités Citoyen

### S'inscrire (`/CitoyenAuth/Register`)
- **Données personnelles :** Nom, Prénom, CIN (unique), Téléphone, Adresse
- **Compte :** Login (unique), Email (unique), Mot de passe (min. 6 caractères)
- **Processus :** Création immédiate, connexion automatique
- **Hachage :** BCrypt avec salt automatique

### Se connecter (`/Auth/Login` — Onglet "Espace Citoyen")
- Login + Mot de passe
- Mise à jour automatique `LastLoginAt`
- Redirection tableau de bord citoyen

### Mot de passe oublié (`/CitoyenAuth/ForgotPassword`)
1. Entrer **Login ou Email** + **CIN** (vérification d'identité)
2. Système génère token valide **2 heures**
3. Réinitialiser le mot de passe (`/CitoyenAuth/ResetPassword`)
4. Retour à la connexion

### Espace Citoyen (`/CitoyenEspace/*`)

#### Dashboard (`/CitoyenEspace`)
- **Statistiques :** Total, En attente, Validés, Rejetés
- **Derniers projets :** Liste des 5 derniers avec statut
- **Fiche profil :** Infos perso + dernier accès

#### Mes projets (`/CitoyenEspace/MesProjets`)
- Liste complète de tous les projets
- Statuts visuels (En attente 🟡, Validé 🟢, Rejeté 🔴)
- Actions : Voir, Modifier (si En attente), Supprimer (si En attente)
- Affichage motif rejet si applicable

#### Soumettre un projet (`/CitoyenEspace/NouveauProjet`)
- **Identification :** Nom, Matricule Fiscale, RNE, Adresse Sociale, Description
- **Classification :** Type projet, Type créateur, Gouvernorat
- **Activités :** Multi-select NACE/APE + activité principale
- **Statut initial :** EnAttente (en attente de validation admin)

#### Modifier un projet (`/CitoyenEspace/ModifierProjet/{id}`)
- Accessible **seulement si Statut = "EnAttente"**
- Formulaire identique à la création
- Sauvegarde mise à jour (`UpdatedAt`)

#### Détails du projet (`/CitoyenEspace/ProjetDetails/{id}`)
- Affichage complet avec toutes les infos
- Tableau des activités NACE liées
- Affichage du **motif de rejet** (si Rejeté)
- Boutons Modifier/Supprimer visibles seulement si En attente

#### Mon profil (`/CitoyenEspace/Profil`)
- **Infos perso :** Nom, Prénom, CIN, Email, Téléphone, Adresse
- **Statut compte :** Membres depuis, Dernier accès
- **Changer mot de passe :** Ancien + Nouveau + Confirmer

---

## 🗄️ Base de données

### Tables principales

```sql
-- Géographie
Gouvernorats (Id, NomFr, NomAr)
Delegations (Id, NomFr, NomAr, GouvernoratId, CodePostal)
Administrations (Id, NomFr, NomAr, GouvernoratId, CodeAdministration)

-- Sécurité
Roles (Id, LibelleFr, LibelleAr, Description)
Users (Id, Login unique, PasswordHash, Email unique, RoleId, IsActive, LastLoginAt, FailedAttempts, IsLocked)
Citoyens (Id, Nom, Prenom, CIN unique, Login unique, Email unique, PasswordHash, IsActive, CreatedAt, LastLoginAt, ResetToken, ResetTokenExpiry)

-- Référence
Genres (Id, LibelleFr, LibelleAr)
TypeProjets (Id, LibelleFr, LibelleAr)
TypeCreateur (Id, LibelleFr, LibelleAr)
TypeLocaux (Id, LibelleFr, LibelleAr)
Activites (Id, CodeNACE_Ape unique, LibelleFr, LibelleAr)

-- Personnes
Agents (Id, Matricule unique, Nom, Prenom, AdministrationId, UserId, TelephoneProfessionnel)
Clients (Id, Nom, Prenom, GenreId, CIN unique, Telephone, Adresse, UserId, CreatedAt, CreatedById, IsDeleted, DeletedAt)

-- Projets (système RBAC)
Projets (Id, NumeroProjet unique auto, ClientId, GouvernoratId, TypeProjetId, TypeCreateurId, NomProjet, MatriculeFiscale unique, RNE unique, EstActif, CreatedAt, CreatedById, IsDeleted)
ProjetActivites (ProjetId, ActiviteId, EstPrincipale)
Locaux (Id, ProjetId, TypeLocalId, DelegationId, Adresse, Surface)
HistoriqueProjets (LogId, ProjetId, AncienNomProjet, AncienneMatriculeFiscale, AncienRNE, AncienEstActif, DateModification, ModifieById)

-- Projets (système citoyen)
CitoyenProjets (Id, CitoyenId, NomProjet, MatriculeFiscale unique, RNE unique, TypeProjetId, GouvernoratId, TypeCreateurId, Statut, CommentaireAdmin, CreatedAt, UpdatedAt)
CitoyenProjetActivites (CitoyenProjetId, ActiviteId, EstPrincipale)
```

### Vues SQL
- `V_Clients_Actifs` — Clients non supprimés avec genre bilingue
- `V_Projets_Actifs` — Projets non supprimés avec toutes les jointures

### Triggers SQL
- `TR_Projets_GenerateNumero` — Génère `PRJ-YYYY-XXXXXX` après INSERT
- `TR_Projets_TrackChanges` — Historise modifications dans HistoriqueProjets

---

## 📁 Structure du projet

```
ErpApp/
├── Models/
│   ├── Models.cs (entités + ViewModels Agent)
│   └── CitoyenModels.cs (entités + ViewModels Citoyen)
├── Controllers/
│   ├── Controllers.cs (tous les contrôleurs Agent/Admin)
│   └── CitoyenController.cs (CitoyenAuthController + CitoyenEspaceController)
├── Services/
│   ├── Services.cs (15 interfaces + implémentations)
│   └── CitoyenService.cs (ICitoyenService)
├── Data/
│   └── AppDbContext.cs (configuration EF Core complet)
├── Views/
│   ├── Auth/
│   │   └── Login.cshtml (2 onglets : Agent + Citoyen)
│   ├── Home/
│   │   └── Index.cshtml (Dashboard Agent/Admin)
│   ├── CitoyenAuth/ (3 vues)
│   │   ├── Register.cshtml
│   │   ├── ForgotPassword.cshtml
│   │   └── ResetPassword.cshtml
│   ├── CitoyenEspace/ (8 vues)
│   │   ├── _CitoyenLayout.cshtml (sidebar vert)
│   │   ├── Index.cshtml (Dashboard citoyen)
│   │   ├── MesProjets.cshtml
│   │   ├── NouveauProjet.cshtml
│   │   ├── ModifierProjet.cshtml
│   │   ├── ProjetDetails.cshtml
│   │   ├── Profil.cshtml
│   │   └── _ViewStart.cshtml
│   ├── Projets/, Clients/, Agents/, Gouvernorats/, etc. (30+ vues)
│   └── Shared/
│       ├── _Layout.cshtml (layout Agent/Admin)
│       ├── _ViewImports.cshtml
│       └── _ViewStart.cshtml
├── wwwroot/
│   ├── css/
│   │   └── app.css (design moderne bilingue)
│   └── js/
│       └── app.js (interactivité, modales, cascade)
├── Database/
│   └── setup.sql (script SQL alternatif)
├── Program.cs (DI, authentification, middlewares)
├── appsettings.json (connection string)
├── ErpApp.csproj (packages : EF Core, BCrypt)
├── README.md (documentation générale)
└── README_CITOYEN.md (documentation Citoyen)
```

---

## ⚙️ Configuration

### appsettings.json
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=ErpDeclarationDB;Trusted_Connection=True;TrustServerCertificate=True"
  }
}
```

### Variantes connexion SQL Server

**SQL Server Express :**
```
Server=.\\SQLEXPRESS;Database=ErpDeclarationDB;Trusted_Connection=True;TrustServerCertificate=True
```

**Azure SQL / Authentification :**
```
Server=monserveur.database.windows.net;Database=ErpDeclarationDB;User Id=user;Password=pass;Encrypt=True;TrustServerCertificate=False
```

**Avec authentification SQL :**
```
Server=monserveur;Database=ErpDeclarationDB;User Id=sa;Password=MyPassword;TrustServerCertificate=True
```

---

## 🔒 Sécurité

✅ **Authentification :**
- Cookie-based ASP.NET Core
- BCrypt hachage mots de passe (salt auto)
- Verrouillage compte après 5 tentatives
- `LastLoginAt` tracking

✅ **Autorisation :**
- `[Authorize]` sur tous les endpoints sensibles
- RBAC : Admin, Agent, Consultant (Agent/Admin)
- Citoyen isolé : ne voit que ses données
- `[Authorize(Roles = "Citoyen")]` sur CitoyenEspace

✅ **Validation :**
- Unicité : Login, Email, CIN, Matricule, MF, RNE
- Contraintes CHECK SQL (Surface > 0)
- Remote validation côté client (CIN déjà utilisé ?)
- ModelState validation

✅ **Protection CSRF :**
- `@Html.AntiForgeryToken()` sur tous les formulaires
- `[ValidateAntiForgeryToken]` sur tous les POST

✅ **Données sensibles :**
- Soft delete pour Clients et Projets (conservation données)
- Historique SQL pour audit Projets
- Reset token expire 2h
- ResetToken + ResetTokenExpiry pour MDP oublié

---

## 📊 Contrôleurs & Actions

### AuthController (Agent/Admin)
- `Login` (GET/POST) — Authentification
- `Logout` — Déconnexion

### CitoyenAuthController (Citoyen)
- `Register` (GET/POST) — Inscription
- `Login` (POST) — Connexion
- `ForgotPassword` (GET/POST) — Récupération compte
- `ResetPassword` (GET/POST) — Nouvelle MDP
- `Logout` — Déconnexion

### CitoyenEspaceController (Citoyen)
- `Index` — Dashboard citoyen
- `Profil` (GET) — Voir infos
- `ChangerMotDePasse` (POST) — Changer MDP
- `MesProjets` — Liste projets
- `ProjetDetails` — Détails
- `NouveauProjet` (GET/POST) — Créer projet
- `ModifierProjet` (GET/POST) — Éditer projet
- `SupprimerProjet` (POST) — Supprimer projet

### HomeController (Agent/Admin)
- `Index` — Dashboard avec stats

### Autres contrôleurs (Agent/Admin)
- GouvernoratsController, DelegationsController, AdministrationsController
- RolesController, UsersController
- AgentsController, ClientsController
- ActivitesController, ProjetsController

---

## 🎨 Design & UX

### Couleurs
- **Primary :** `#1a56db` (bleu)
- **Sidebar Admin :** `#0f172a` (noir)
- **Sidebar Citoyen :** `#065f46` (vert tendre)
- **Background :** `#f1f5f9` (gris clair)
- **Success :** `#10b981` (vert)
- **Warning :** `#f59e0b` (amber)
- **Danger :** `#ef4444` (rouge)

### Typographie
- **Font :** Inter (Google Fonts)
- **Headings :** 700 weight
- **Body :** 400-500 weight

### Bilingue FR/عربي
- Classe CSS `.ar` = `direction: rtl`
- `dir="rtl"` sur inputs arabes
- Tous les libellés bilingues dans la BD

### Responsive
- Mobile-first
- Sidebar fixe sur desktop, hamburger sur mobile
- Grilles CSS auto-fill
- Tables scrollables

---

## 📝 Comptes de test

### Agent/Admin
```
URL: https://localhost:5001/Auth/Login
Login: admin
Mot de passe: Admin@123
Rôle: Administrateur
```

### Citoyen
```
URL: https://localhost:5001/Auth/Login (onglet Citoyen)
Option 1: Créer un nouveau compte (Register)
Option 2: Tester récupération compte oublié
```

**Exemple citoyen pré-créé (optionnel) :**
```
Login: citizen1
Email: citizen@example.tn
Mot de passe: Password123
```

---

## 🔧 Commandes utiles

```bash
# Migrations
dotnet ef migrations add NomDeLaMigration
dotnet ef database update
dotnet ef database drop -f

# Lancer l'app
dotnet run
dotnet watch run (avec hot reload)

# Build
dotnet build
dotnet publish -c Release

# Tests (si implémentés)
dotnet test
```

---

## 📦 Packages NuGet

```xml
<PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.0" />
<PackageReference Include="Microsoft.EntityFrameworkCore.Tools" Version="8.0.0" />
<PackageReference Include="Microsoft.EntityFrameworkCore.Design" Version="8.0.0" />
<PackageReference Include="BCrypt.Net-Next" Version="4.0.3" />
```

---

## 🐛 Dépannage

### Erreur de connexion SQL
```
"Login failed for user '(localdb)\\mssqllocaldb'"
```
**Solution :** Vérifier `appsettings.json`, créer BD manuellement, ou utiliser SQL Server Express

### Migration échoue
```bash
dotnet ef database drop -f
dotnet ef database update
```

### Port 5001 déjà utilisé
Modifier `Program.cs` ou `Properties\launchSettings.json`

### Bicrypt "Illegal base64 character"
Erreur MDP → Vérifier hash BCrypt, régénérer si besoin

---

## 📈 Performance

- **EF Core :** `.Include()` eagerly chargé pour relations
- **Indexes :** Créés sur Login, Email, CIN, MF, RNE
- **Caching :** À implémenter (Redis recommandé)
- **Pagination :** À implémenter pour gros datasets

---

## 🚀 Prochaines étapes

- ✅ Inscription citoyen
- ✅ Espace citoyen complet
- ✅ Mot de passe oublié
- ⏳ Notifications email
- ⏳ Upload de fichiers
- ⏳ API REST (Swagger)
- ⏳ Tests unitaires
- ⏳ CI/CD (GitHub Actions)
- ⏳ Docker & Kubernetes

---

## 📞 Support

- **Documentation :** Consultez README.md et README_CITOYEN.md
- **Code source :** Tous les fichiers commentés
- **Issues :** Décrivez le problème et reproduisez si possible

---

**ERP Déclaration v2.5 © 2026**  
**Développé avec ❤️ en ASP.NET Core 8**
