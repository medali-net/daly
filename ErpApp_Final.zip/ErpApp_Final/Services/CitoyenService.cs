using ErpApp.Data;
using ErpApp.Models;
using Microsoft.EntityFrameworkCore;

namespace ErpApp.Services
{
    public interface ICitoyenService
    {
        Task<Citoyen?> GetByIdAsync(int id);
        Task<Citoyen?> GetByLoginAsync(string login);
        Task<bool> LoginExistsAsync(string login);
        Task<bool> EmailExistsAsync(string email);
        Task<bool> CINExistsAsync(string cin);
        Task<Citoyen> RegisterAsync(RegisterCitoyenViewModel vm);
        Task<bool> ValidatePasswordAsync(string login, string password);
        Task UpdateAsync(Citoyen c);

        // Mot de passe oublié
        Task<Citoyen?> FindForResetAsync(string loginOrEmail, string cin);
        Task<string> GenerateResetTokenAsync(Citoyen c);
        Task<Citoyen?> GetByResetTokenAsync(string token);
        Task<bool> ResetPasswordAsync(string token, string newPassword);

        // Projets citoyen
        Task<IEnumerable<CitoyenProjet>> GetProjetsAsync(int citoyenId);
        Task<CitoyenProjet?> GetProjetByIdAsync(int id, int citoyenId);
        Task<CitoyenProjet> CreateProjetAsync(CitoyenProjet p, List<int> activiteIds, int? principaleId);
        Task UpdateProjetAsync(CitoyenProjet p, List<int> activiteIds, int? principaleId);
        Task<bool> DeleteProjetAsync(int id, int citoyenId);
        Task<CitoyenDashboardViewModel> GetDashboardAsync(int citoyenId);
    }

    public class CitoyenService : ICitoyenService
    {
        private readonly AppDbContext _db;
        public CitoyenService(AppDbContext db) { _db = db; }

        public async Task<Citoyen?> GetByIdAsync(int id) =>
            await _db.Citoyens.FirstOrDefaultAsync(c => c.Id == id && c.IsActive);

        public async Task<Citoyen?> GetByLoginAsync(string login) =>
            await _db.Citoyens.FirstOrDefaultAsync(c => c.Login == login && c.IsActive);

        public async Task<bool> LoginExistsAsync(string login) =>
            await _db.Citoyens.AnyAsync(c => c.Login == login) ||
            await _db.Users.AnyAsync(u => u.Login == login);

        public async Task<bool> EmailExistsAsync(string email) =>
            await _db.Citoyens.AnyAsync(c => c.Email == email);

        public async Task<bool> CINExistsAsync(string cin) =>
            await _db.Citoyens.AnyAsync(c => c.CIN == cin);

        public async Task<Citoyen> RegisterAsync(RegisterCitoyenViewModel vm)
        {
            var citoyen = new Citoyen
            {
                Nom = vm.Nom,
                Prenom = vm.Prenom,
                CIN = vm.CIN,
                Telephone = vm.Telephone,
                Adresse = vm.Adresse,
                Login = vm.Login,
                Email = vm.Email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(vm.Password),
                CreatedAt = DateTime.Now,
                IsActive = true
            };
            _db.Citoyens.Add(citoyen);
            await _db.SaveChangesAsync();
            return citoyen;
        }

        public async Task<bool> ValidatePasswordAsync(string login, string password)
        {
            var c = await _db.Citoyens.FirstOrDefaultAsync(x => x.Login == login && x.IsActive);
            return c != null && BCrypt.Net.BCrypt.Verify(password, c.PasswordHash);
        }

        public async Task UpdateAsync(Citoyen c)
        {
            _db.Citoyens.Update(c);
            await _db.SaveChangesAsync();
        }

        public async Task<Citoyen?> FindForResetAsync(string loginOrEmail, string cin) =>
            await _db.Citoyens.FirstOrDefaultAsync(c =>
                (c.Login == loginOrEmail || c.Email == loginOrEmail) && c.CIN == cin && c.IsActive);

        public async Task<string> GenerateResetTokenAsync(Citoyen c)
        {
            var token = Guid.NewGuid().ToString("N") + Guid.NewGuid().ToString("N");
            c.ResetToken = token;
            c.ResetTokenExpiry = DateTime.Now.AddHours(2);
            await UpdateAsync(c);
            return token;
        }

        public async Task<Citoyen?> GetByResetTokenAsync(string token) =>
            await _db.Citoyens.FirstOrDefaultAsync(c =>
                c.ResetToken == token && c.ResetTokenExpiry > DateTime.Now && c.IsActive);

        public async Task<bool> ResetPasswordAsync(string token, string newPassword)
        {
            var c = await GetByResetTokenAsync(token);
            if (c == null) return false;
            c.PasswordHash = BCrypt.Net.BCrypt.HashPassword(newPassword);
            c.ResetToken = null;
            c.ResetTokenExpiry = null;
            await UpdateAsync(c);
            return true;
        }

        public async Task<IEnumerable<CitoyenProjet>> GetProjetsAsync(int citoyenId) =>
            await _db.CitoyenProjets
                .Include(p => p.TypeProjet)
                .Include(p => p.Gouvernorat)
                .Include(p => p.TypeCreateur)
                .Include(p => p.Activites).ThenInclude(a => a.Activite)
                .Where(p => p.CitoyenId == citoyenId)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();

        public async Task<CitoyenProjet?> GetProjetByIdAsync(int id, int citoyenId) =>
            await _db.CitoyenProjets
                .Include(p => p.TypeProjet)
                .Include(p => p.Gouvernorat)
                .Include(p => p.TypeCreateur)
                .Include(p => p.Activites).ThenInclude(a => a.Activite)
                .FirstOrDefaultAsync(p => p.Id == id && p.CitoyenId == citoyenId);

        public async Task<CitoyenProjet> CreateProjetAsync(CitoyenProjet p, List<int> activiteIds, int? principaleId)
        {
            p.CreatedAt = DateTime.Now;
            p.Statut = "EnAttente";
            _db.CitoyenProjets.Add(p);
            await _db.SaveChangesAsync();
            foreach (var aid in activiteIds)
                _db.CitoyenProjetActivites.Add(new CitoyenProjetActivite
                    { CitoyenProjetId = p.Id, ActiviteId = aid, EstPrincipale = aid == principaleId });
            await _db.SaveChangesAsync();
            return p;
        }

        public async Task UpdateProjetAsync(CitoyenProjet p, List<int> activiteIds, int? principaleId)
        {
            p.UpdatedAt = DateTime.Now;
            _db.CitoyenProjets.Update(p);
            var existing = _db.CitoyenProjetActivites.Where(a => a.CitoyenProjetId == p.Id);
            _db.CitoyenProjetActivites.RemoveRange(existing);
            foreach (var aid in activiteIds)
                _db.CitoyenProjetActivites.Add(new CitoyenProjetActivite
                    { CitoyenProjetId = p.Id, ActiviteId = aid, EstPrincipale = aid == principaleId });
            await _db.SaveChangesAsync();
        }

        public async Task<bool> DeleteProjetAsync(int id, int citoyenId)
        {
            var p = await _db.CitoyenProjets.FirstOrDefaultAsync(x => x.Id == id && x.CitoyenId == citoyenId);
            if (p == null) return false;
            if (p.Statut == "Validé") return false; // Ne peut pas supprimer un projet validé
            _db.CitoyenProjets.Remove(p);
            await _db.SaveChangesAsync();
            return true;
        }

        public async Task<CitoyenDashboardViewModel> GetDashboardAsync(int citoyenId)
        {
            var citoyen = await GetByIdAsync(citoyenId);
            var projets = await _db.CitoyenProjets
                .Include(p => p.TypeProjet)
                .Where(p => p.CitoyenId == citoyenId)
                .ToListAsync();
            return new CitoyenDashboardViewModel
            {
                Citoyen = citoyen!,
                TotalProjets = projets.Count,
                ProjetsEnAttente = projets.Count(p => p.Statut == "EnAttente"),
                ProjetsValides = projets.Count(p => p.Statut == "Validé"),
                ProjetsRejetes = projets.Count(p => p.Statut == "Rejeté"),
                DerniersProjets = projets.OrderByDescending(p => p.CreatedAt).Take(5).ToList()
            };
        }
    }
}
