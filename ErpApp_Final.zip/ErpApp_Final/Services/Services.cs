using ErpApp.Models;
using ErpApp.Data;
using Microsoft.EntityFrameworkCore;

namespace ErpApp.Services
{
    // =====================================================================
    // GENERIC INTERFACES
    // =====================================================================
    public interface IDashboardService { Task<DashboardViewModel> GetAsync(); }
    public interface IGouvernoratService { Task<IEnumerable<Gouvernorat>> GetAllAsync(); Task<Gouvernorat?> GetByIdAsync(int id); Task CreateAsync(Gouvernorat e); Task UpdateAsync(Gouvernorat e); Task<bool> DeleteAsync(int id); Task<bool> ExistsAsync(string nomFr, int? excludeId); }
    public interface IDelegationService { Task<IEnumerable<Delegation>> GetAllAsync(int? gouvernoratId = null); Task<Delegation?> GetByIdAsync(int id); Task CreateAsync(Delegation e); Task UpdateAsync(Delegation e); Task<bool> DeleteAsync(int id); }
    public interface IAdministrationService { Task<IEnumerable<Administration>> GetAllAsync(); Task<Administration?> GetByIdAsync(int id); Task CreateAsync(Administration e); Task UpdateAsync(Administration e); Task<bool> DeleteAsync(int id); Task<bool> CodeExistsAsync(string code, int? excludeId); }
    public interface IRoleService { Task<IEnumerable<Role>> GetAllAsync(); Task<Role?> GetByIdAsync(int id); Task CreateAsync(Role e); Task UpdateAsync(Role e); Task<bool> DeleteAsync(int id); }
    public interface IUserService { Task<IEnumerable<User>> GetAllAsync(); Task<User?> GetByIdAsync(int id); Task<User?> GetByLoginAsync(string login); Task CreateAsync(User e, string password); Task UpdateAsync(User e); Task<bool> DeleteAsync(int id); Task<bool> LoginExistsAsync(string login, int? excludeId); Task<bool> ValidatePasswordAsync(string login, string password); }
    public interface IGenreService { Task<IEnumerable<Genre>> GetAllAsync(); }
    public interface IAgentService { Task<IEnumerable<Agent>> GetAllAsync(string? search = null); Task<Agent?> GetByIdAsync(int id); Task CreateAsync(Agent e); Task UpdateAsync(Agent e); Task<bool> DeleteAsync(int id); Task<bool> MatriculeExistsAsync(string matricule, int? excludeId); }
    public interface IClientService { Task<IEnumerable<Client>> GetAllAsync(string? search = null, int? genreId = null); Task<Client?> GetByIdAsync(int id); Task CreateAsync(Client e); Task UpdateAsync(Client e); Task<bool> SoftDeleteAsync(int id, int byUserId); Task<bool> CINExistsAsync(string cin, int? excludeId); }
    public interface IActiviteService { Task<IEnumerable<Activite>> GetAllAsync(string? search = null); Task<Activite?> GetByIdAsync(int id); Task CreateAsync(Activite e); Task UpdateAsync(Activite e); Task<bool> DeleteAsync(int id); Task<bool> CodeExistsAsync(string code, int? excludeId); }
    public interface ITypeProjetService { Task<IEnumerable<TypeProjet>> GetAllAsync(); }
    public interface ITypeCreateurService { Task<IEnumerable<TypeCreateur>> GetAllAsync(); }
    public interface ITypeLocalService { Task<IEnumerable<TypeLocal>> GetAllAsync(); }
    public interface IProjetService {
        Task<IEnumerable<Projet>> GetAllAsync(string? search = null, int? typeId = null, bool? actif = null);
        Task<Projet?> GetByIdAsync(int id);
        Task<int> CreateAsync(Projet p, List<int> activiteIds, int? principaleId);
        Task UpdateAsync(Projet p, List<int> activiteIds, int? principaleId, int userId);
        Task<bool> SoftDeleteAsync(int id, int byUserId);
        Task<bool> MFExistsAsync(string mf, int? excludeId);
        Task<bool> RNEExistsAsync(string rne, int? excludeId);
        Task<IEnumerable<HistoriqueProjet>> GetHistoriqueAsync(int projetId);
    }
    public interface ILocalService {
        Task<IEnumerable<Local>> GetByProjetAsync(int projetId);
        Task<Local?> GetByIdAsync(int id);
        Task CreateAsync(Local e);
        Task UpdateAsync(Local e);
        Task<bool> DeleteAsync(int id);
    }

    // =====================================================================
    // IMPLEMENTATIONS
    // =====================================================================
    public class DashboardService : IDashboardService
    {
        private readonly AppDbContext _db;
        public DashboardService(AppDbContext db) { _db = db; }
        public async Task<DashboardViewModel> GetAsync()
        {
            var now = DateTime.Now;
            var clients = _db.Clients.Where(c => !c.IsDeleted);
            var projets = _db.Projets.Include(p => p.TypeProjet).Include(p => p.Gouvernorat).Where(p => !p.IsDeleted);
            return new DashboardViewModel
            {
                TotalClients = await clients.CountAsync(),
                TotalProjets = await projets.CountAsync(),
                TotalAgents = await _db.Agents.CountAsync(),
                ProjetsActifs = await projets.CountAsync(p => p.EstActif),
                ProjetsInactifs = await projets.CountAsync(p => !p.EstActif),
                NouveauxClientsMois = await clients.CountAsync(c => c.CreatedAt.Month == now.Month && c.CreatedAt.Year == now.Year),
                NouveauxProjetsMois = await projets.CountAsync(p => p.CreatedAt.Month == now.Month && p.CreatedAt.Year == now.Year),
                DerniersProjets = await projets.OrderByDescending(p => p.CreatedAt).Take(6).Include(p => p.Client).ToListAsync(),
                DerniersClients = await clients.OrderByDescending(c => c.CreatedAt).Take(5).Include(c => c.Genre).ToListAsync(),
                ProjetsByType = await projets.GroupBy(p => p.TypeProjet!.LibelleFr).Select(g => new { g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Count),
                ProjetsByGouvernorat = await projets.GroupBy(p => p.Gouvernorat!.NomFr).Select(g => new { g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Count)
            };
        }
    }

    public class GouvernoratService : IGouvernoratService
    {
        private readonly AppDbContext _db;
        public GouvernoratService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<Gouvernorat>> GetAllAsync() => await _db.Gouvernorats.OrderBy(g => g.NomFr).ToListAsync();
        public async Task<Gouvernorat?> GetByIdAsync(int id) => await _db.Gouvernorats.FindAsync(id);
        public async Task CreateAsync(Gouvernorat e) { _db.Gouvernorats.Add(e); await _db.SaveChangesAsync(); }
        public async Task UpdateAsync(Gouvernorat e) { _db.Gouvernorats.Update(e); await _db.SaveChangesAsync(); }
        public async Task<bool> DeleteAsync(int id) { var e = await _db.Gouvernorats.FindAsync(id); if (e == null) return false; _db.Gouvernorats.Remove(e); await _db.SaveChangesAsync(); return true; }
        public async Task<bool> ExistsAsync(string nomFr, int? excludeId) => await _db.Gouvernorats.AnyAsync(g => g.NomFr == nomFr && (!excludeId.HasValue || g.Id != excludeId));
    }

    public class DelegationService : IDelegationService
    {
        private readonly AppDbContext _db;
        public DelegationService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<Delegation>> GetAllAsync(int? gouvernoratId = null)
        {
            var q = _db.Delegations.Include(d => d.Gouvernorat).AsQueryable();
            if (gouvernoratId.HasValue) q = q.Where(d => d.GouvernoratId == gouvernoratId);
            return await q.OrderBy(d => d.NomFr).ToListAsync();
        }
        public async Task<Delegation?> GetByIdAsync(int id) => await _db.Delegations.Include(d => d.Gouvernorat).FirstOrDefaultAsync(d => d.Id == id);
        public async Task CreateAsync(Delegation e) { _db.Delegations.Add(e); await _db.SaveChangesAsync(); }
        public async Task UpdateAsync(Delegation e) { _db.Delegations.Update(e); await _db.SaveChangesAsync(); }
        public async Task<bool> DeleteAsync(int id) { var e = await _db.Delegations.FindAsync(id); if (e == null) return false; _db.Delegations.Remove(e); await _db.SaveChangesAsync(); return true; }
    }

    public class AdministrationService : IAdministrationService
    {
        private readonly AppDbContext _db;
        public AdministrationService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<Administration>> GetAllAsync() => await _db.Administrations.Include(a => a.Gouvernorat).OrderBy(a => a.NomFr).ToListAsync();
        public async Task<Administration?> GetByIdAsync(int id) => await _db.Administrations.Include(a => a.Gouvernorat).FirstOrDefaultAsync(a => a.Id == id);
        public async Task CreateAsync(Administration e) { _db.Administrations.Add(e); await _db.SaveChangesAsync(); }
        public async Task UpdateAsync(Administration e) { _db.Administrations.Update(e); await _db.SaveChangesAsync(); }
        public async Task<bool> DeleteAsync(int id) { var e = await _db.Administrations.FindAsync(id); if (e == null) return false; _db.Administrations.Remove(e); await _db.SaveChangesAsync(); return true; }
        public async Task<bool> CodeExistsAsync(string code, int? excludeId) => await _db.Administrations.AnyAsync(a => a.CodeAdministration == code && (!excludeId.HasValue || a.Id != excludeId));
    }

    public class RoleService : IRoleService
    {
        private readonly AppDbContext _db;
        public RoleService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<Role>> GetAllAsync() => await _db.Roles.OrderBy(r => r.LibelleFr).ToListAsync();
        public async Task<Role?> GetByIdAsync(int id) => await _db.Roles.FindAsync(id);
        public async Task CreateAsync(Role e) { _db.Roles.Add(e); await _db.SaveChangesAsync(); }
        public async Task UpdateAsync(Role e) { _db.Roles.Update(e); await _db.SaveChangesAsync(); }
        public async Task<bool> DeleteAsync(int id) { var e = await _db.Roles.FindAsync(id); if (e == null) return false; _db.Roles.Remove(e); await _db.SaveChangesAsync(); return true; }
    }

    public class UserService : IUserService
    {
        private readonly AppDbContext _db;
        public UserService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<User>> GetAllAsync() => await _db.Users.Include(u => u.Role).OrderBy(u => u.Login).ToListAsync();
        public async Task<User?> GetByIdAsync(int id) => await _db.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == id);
        public async Task<User?> GetByLoginAsync(string login) => await _db.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Login == login);
        public async Task CreateAsync(User e, string password) { e.PasswordHash = BCrypt.Net.BCrypt.HashPassword(password); _db.Users.Add(e); await _db.SaveChangesAsync(); }
        public async Task UpdateAsync(User e) { _db.Users.Update(e); await _db.SaveChangesAsync(); }
        public async Task<bool> DeleteAsync(int id) { var e = await _db.Users.FindAsync(id); if (e == null) return false; _db.Users.Remove(e); await _db.SaveChangesAsync(); return true; }
        public async Task<bool> LoginExistsAsync(string login, int? excludeId) => await _db.Users.AnyAsync(u => u.Login == login && (!excludeId.HasValue || u.Id != excludeId));
        public async Task<bool> ValidatePasswordAsync(string login, string password)
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.Login == login && u.IsActive && !u.IsLocked);
            return user != null && BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);
        }
    }

    public class GenreService : IGenreService
    {
        private readonly AppDbContext _db;
        public GenreService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<Genre>> GetAllAsync() => await _db.Genres.OrderBy(g => g.LibelleFr).ToListAsync();
    }

    public class AgentService : IAgentService
    {
        private readonly AppDbContext _db;
        public AgentService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<Agent>> GetAllAsync(string? search = null)
        {
            var q = _db.Agents.Include(a => a.Administration).ThenInclude(a => a!.Gouvernorat).AsQueryable();
            if (!string.IsNullOrWhiteSpace(search)) { search = search.ToLower(); q = q.Where(a => a.Nom.ToLower().Contains(search) || a.Prenom.ToLower().Contains(search) || a.Matricule.Contains(search)); }
            return await q.OrderBy(a => a.Nom).ToListAsync();
        }
        public async Task<Agent?> GetByIdAsync(int id) => await _db.Agents.Include(a => a.Administration).ThenInclude(a => a!.Gouvernorat).Include(a => a.User).FirstOrDefaultAsync(a => a.Id == id);
        public async Task CreateAsync(Agent e) { _db.Agents.Add(e); await _db.SaveChangesAsync(); }
        public async Task UpdateAsync(Agent e) { _db.Agents.Update(e); await _db.SaveChangesAsync(); }
        public async Task<bool> DeleteAsync(int id) { var e = await _db.Agents.FindAsync(id); if (e == null) return false; _db.Agents.Remove(e); await _db.SaveChangesAsync(); return true; }
        public async Task<bool> MatriculeExistsAsync(string matricule, int? excludeId) => await _db.Agents.AnyAsync(a => a.Matricule == matricule && (!excludeId.HasValue || a.Id != excludeId));
    }

    public class ClientService : IClientService
    {
        private readonly AppDbContext _db;
        public ClientService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<Client>> GetAllAsync(string? search = null, int? genreId = null)
        {
            var q = _db.Clients.Include(c => c.Genre).Where(c => !c.IsDeleted);
            if (!string.IsNullOrWhiteSpace(search)) { var s = search.ToLower(); q = q.Where(c => c.Nom.ToLower().Contains(s) || c.Prenom.ToLower().Contains(s) || c.CIN.ToLower().Contains(s) || (c.Telephone != null && c.Telephone.Contains(s))); }
            if (genreId.HasValue) q = q.Where(c => c.GenreId == genreId);
            return await q.OrderBy(c => c.Nom).ThenBy(c => c.Prenom).ToListAsync();
        }
        public async Task<Client?> GetByIdAsync(int id) => await _db.Clients.Include(c => c.Genre).Include(c => c.Projets).FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);
        public async Task CreateAsync(Client e) { e.CreatedAt = DateTime.Now; _db.Clients.Add(e); await _db.SaveChangesAsync(); }
        public async Task UpdateAsync(Client e) { e.UpdatedAt = DateTime.Now; _db.Clients.Update(e); await _db.SaveChangesAsync(); }
        public async Task<bool> SoftDeleteAsync(int id, int byUserId) { var e = await _db.Clients.FindAsync(id); if (e == null) return false; e.IsDeleted = true; e.DeletedAt = DateTime.Now; e.DeletedById = byUserId; await _db.SaveChangesAsync(); return true; }
        public async Task<bool> CINExistsAsync(string cin, int? excludeId) => await _db.Clients.AnyAsync(c => c.CIN == cin && !c.IsDeleted && (!excludeId.HasValue || c.Id != excludeId));
    }

    public class ActiviteService : IActiviteService
    {
        private readonly AppDbContext _db;
        public ActiviteService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<Activite>> GetAllAsync(string? search = null)
        {
            var q = _db.Activites.AsQueryable();
            if (!string.IsNullOrWhiteSpace(search)) { var s = search.ToLower(); q = q.Where(a => a.LibelleFr.ToLower().Contains(s) || a.CodeNACE_Ape.Contains(s)); }
            return await q.OrderBy(a => a.LibelleFr).ToListAsync();
        }
        public async Task<Activite?> GetByIdAsync(int id) => await _db.Activites.FindAsync(id);
        public async Task CreateAsync(Activite e) { _db.Activites.Add(e); await _db.SaveChangesAsync(); }
        public async Task UpdateAsync(Activite e) { _db.Activites.Update(e); await _db.SaveChangesAsync(); }
        public async Task<bool> DeleteAsync(int id) { var e = await _db.Activites.FindAsync(id); if (e == null) return false; _db.Activites.Remove(e); await _db.SaveChangesAsync(); return true; }
        public async Task<bool> CodeExistsAsync(string code, int? excludeId) => await _db.Activites.AnyAsync(a => a.CodeNACE_Ape == code && (!excludeId.HasValue || a.Id != excludeId));
    }

    public class TypeProjetService : ITypeProjetService
    {
        private readonly AppDbContext _db;
        public TypeProjetService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<TypeProjet>> GetAllAsync() => await _db.TypeProjets.OrderBy(t => t.LibelleFr).ToListAsync();
    }

    public class TypeCreateurService : ITypeCreateurService
    {
        private readonly AppDbContext _db;
        public TypeCreateurService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<TypeCreateur>> GetAllAsync() => await _db.TypeCreateurs.OrderBy(t => t.LibelleFr).ToListAsync();
    }

    public class TypeLocalService : ITypeLocalService
    {
        private readonly AppDbContext _db;
        public TypeLocalService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<TypeLocal>> GetAllAsync() => await _db.TypeLocaux.OrderBy(t => t.LibelleFr).ToListAsync();
    }

    public class ProjetService : IProjetService
    {
        private readonly AppDbContext _db;
        public ProjetService(AppDbContext db) { _db = db; }

        public async Task<IEnumerable<Projet>> GetAllAsync(string? search = null, int? typeId = null, bool? actif = null)
        {
            var q = _db.Projets.Include(p => p.Client).Include(p => p.Gouvernorat).Include(p => p.TypeProjet).Include(p => p.TypeCreateur).Where(p => !p.IsDeleted);
            if (!string.IsNullOrWhiteSpace(search)) { var s = search.ToLower(); q = q.Where(p => p.NomProjet.ToLower().Contains(s) || (p.NumeroProjet != null && p.NumeroProjet.Contains(s)) || p.MatriculeFiscale.Contains(s)); }
            if (typeId.HasValue) q = q.Where(p => p.TypeProjetId == typeId);
            if (actif.HasValue) q = q.Where(p => p.EstActif == actif);
            return await q.OrderByDescending(p => p.CreatedAt).ToListAsync();
        }

        public async Task<Projet?> GetByIdAsync(int id) => await _db.Projets
            .Include(p => p.Client).ThenInclude(c => c!.Genre)
            .Include(p => p.Gouvernorat)
            .Include(p => p.TypeProjet)
            .Include(p => p.TypeCreateur)
            .Include(p => p.ProjetActivites).ThenInclude(pa => pa.Activite)
            .Include(p => p.Locaux).ThenInclude(l => l.TypeLocal)
            .Include(p => p.Locaux).ThenInclude(l => l.Delegation).ThenInclude(d => d!.Gouvernorat)
            .FirstOrDefaultAsync(p => p.Id == id && !p.IsDeleted);

        public async Task<int> CreateAsync(Projet p, List<int> activiteIds, int? principaleId)
        {
            p.CreatedAt = DateTime.Now;
            _db.Projets.Add(p);
            await _db.SaveChangesAsync();
            // Auto-generate numero
            p.NumeroProjet = $"PRJ-{DateTime.Now.Year}-{p.Id:D6}";
            foreach (var aid in activiteIds)
                p.ProjetActivites.Add(new ProjetActivite { ProjetId = p.Id, ActiviteId = aid, EstPrincipale = aid == principaleId });
            await _db.SaveChangesAsync();
            return p.Id;
        }

        public async Task UpdateAsync(Projet p, List<int> activiteIds, int? principaleId, int userId)
        {
            p.UpdatedAt = DateTime.Now;
            p.UpdatedById = userId;
            _db.Projets.Update(p);
            var existing = _db.ProjetActivites.Where(pa => pa.ProjetId == p.Id);
            _db.ProjetActivites.RemoveRange(existing);
            foreach (var aid in activiteIds)
                _db.ProjetActivites.Add(new ProjetActivite { ProjetId = p.Id, ActiviteId = aid, EstPrincipale = aid == principaleId });
            await _db.SaveChangesAsync();
        }

        public async Task<bool> SoftDeleteAsync(int id, int byUserId)
        {
            var e = await _db.Projets.FindAsync(id);
            if (e == null) return false;
            e.IsDeleted = true; e.EstActif = false; e.DeletedAt = DateTime.Now; e.DeletedById = byUserId;
            await _db.SaveChangesAsync();
            return true;
        }

        public async Task<bool> MFExistsAsync(string mf, int? excludeId) => await _db.Projets.AnyAsync(p => p.MatriculeFiscale == mf && !p.IsDeleted && (!excludeId.HasValue || p.Id != excludeId));
        public async Task<bool> RNEExistsAsync(string rne, int? excludeId) => await _db.Projets.AnyAsync(p => p.RNE == rne && !p.IsDeleted && (!excludeId.HasValue || p.Id != excludeId));
        public async Task<IEnumerable<HistoriqueProjet>> GetHistoriqueAsync(int projetId) => await _db.HistoriqueProjets.Where(h => h.ProjetId == projetId).Include(h => h.ModifiePar).OrderByDescending(h => h.DateModification).ToListAsync();
    }

    public class LocalService : ILocalService
    {
        private readonly AppDbContext _db;
        public LocalService(AppDbContext db) { _db = db; }
        public async Task<IEnumerable<Local>> GetByProjetAsync(int projetId) => await _db.Locaux.Include(l => l.TypeLocal).Include(l => l.Delegation).ThenInclude(d => d!.Gouvernorat).Where(l => l.ProjetId == projetId).ToListAsync();
        public async Task<Local?> GetByIdAsync(int id) => await _db.Locaux.Include(l => l.TypeLocal).Include(l => l.Delegation).FirstOrDefaultAsync(l => l.Id == id);
        public async Task CreateAsync(Local e) { _db.Locaux.Add(e); await _db.SaveChangesAsync(); }
        public async Task UpdateAsync(Local e) { _db.Locaux.Update(e); await _db.SaveChangesAsync(); }
        public async Task<bool> DeleteAsync(int id) { var e = await _db.Locaux.FindAsync(id); if (e == null) return false; _db.Locaux.Remove(e); await _db.SaveChangesAsync(); return true; }
    }
}
