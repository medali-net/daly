// === SIDEBAR ===
function toggleSidebar(){document.querySelector('.sidebar').classList.toggle('open')}

// === DELETE MODAL ===
let _deleteForm=null;
function confirmDelete(formId,name){
  _deleteForm=document.getElementById(formId);
  const el=document.getElementById('delName');
  if(el)el.textContent=name||'cet élément';
  document.getElementById('deleteModal').classList.add('open');
}
function closeDeleteModal(){document.getElementById('deleteModal').classList.remove('open');_deleteForm=null;}
function proceedDelete(){if(_deleteForm)_deleteForm.submit();closeDeleteModal();}
document.addEventListener('click',e=>{if(e.target.classList.contains('modal-overlay'))closeDeleteModal();});

// === TABS ===
function showTab(id){
  document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById(id)?.classList.add('active');
  document.querySelector(`[data-tab="${id}"]`)?.classList.add('active');
}

// === AUTO-DISMISS ALERTS ===
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('.alert[data-ac]').forEach(a=>{
    setTimeout(()=>{a.style.transition='opacity .4s';a.style.opacity='0';setTimeout(()=>a.remove(),400);},4500);
  });

  // Active nav
  const path=window.location.pathname.toLowerCase();
  document.querySelectorAll('.nav-link').forEach(l=>{
    const href=(l.getAttribute('href')||'').toLowerCase();
    if(href!=='/'&&path.startsWith(href))l.classList.add('active');
    else if(href==='/'&&path==='/')l.classList.add('active');
  });

  // First tab
  const firstTab=document.querySelector('.tab-btn');
  if(firstTab)firstTab.click();
});

// === DELEGATION CASCADE ===
async function loadDelegations(gouvernoratId, selectEl, selectedId=null){
  if(!gouvernoratId||!selectEl)return;
  const res=await fetch(`/Delegations/GetByGouvernorat?gouvernoratId=${gouvernoratId}`);
  const data=await res.json();
  selectEl.innerHTML='<option value="">— Sélectionner —</option>';
  data.forEach(d=>{
    const opt=document.createElement('option');
    opt.value=d.id; opt.textContent=d.text;
    if(d.id==selectedId)opt.selected=true;
    selectEl.appendChild(opt);
  });
}
