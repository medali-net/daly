# 🏛️ ERP Déclaration v2.5 — Espace Citoyen INTÉGRÉ

## ✨ Nouvelle fonctionnalité : Espace Citoyen complet

### 👤 Citoyen : Inscription & Gestion de projets

Les citoyens peuvent maintenant :

1. **S'inscrire** sans rôle ni permission (`/CitoyenAuth/Register`)
2. **Se connecter** à l'espace citoyen (`/Auth/Login` → onglet "Espace Citoyen")
3. **Soumettre leurs propres projets** avec activités NACE/APE
4. **Modifier les projets** en attente de validation uniquement
5. **Supprimer les projets** non validés
6. **Consulter l'historique** de leurs projets (statut : EnAttente, Validé, Rejeté)
7. **Modifier leur mot de passe** à tout moment
8. **Récupérer un compte oublié** par Login/Email + vérification CIN

---

## 🔐 Flux d'authentification Citoyen

### Inscription (`/CitoyenAuth/Register`)
- Nom, Prénom, CIN (unique), Téléphone, Adresse
- Login (unique), Email (unique), Mot de passe min. 6 caractères
- Compte créé immédiatement **sans approbation**
- Connexion automatique après inscription

### Connexion (`/Auth/Login` — Onglet "Espace Citoyen")
- Login + Mot de passe
- Mise à jour automatique de `LastLoginAt`
- Redirection vers tableau de bord citoyen

### Mot de passe oublié (`/CitoyenAuth/ForgotPassword`)
1. Entrer **Login ou Email** + **CIN** (vérification d'identité)
2. Système génère un token valide 2h
3. Réinitialiser le mot de passe sans lien email (démo)
4. Redirection vers connexion

---

## 📁 Espace Citoyen (`/CitoyenEspace/*`)

### Dashboard (`/CitoyenEspace`)
- Statistiques : Total projets, En attente, Validés, Rejetés
- Tableau des 5 derniers projets
- Fiche profil citoyen avec dernier accès

### Mes projets (`/CitoyenEspace/MesProjets`)
- Liste de tous les projets du citoyen
- Filtrage par statut
- Actions : Voir, Modifier (si EnAttente), Supprimer (si EnAttente)

### Soumettre un projet (`/CitoyenEspace/NouveauProjet`)
- Nom, Matricule Fiscale, RNE, Adresse Sociale, Description
- Type de projet (Industriel, Commercial, Service, Agricole)
- Type de créateur (Personne Physique, Personne Morale)
- Gouvernorat
- Sélection multi-checkbox des activités NACE/APE + activité principale
- **Statut initial : EnAttente** (en attente de validation admin)

### Modifier un projet (`/CitoyenEspace/ModifierProjet/{id}`)
- Accessible seulement si **Statut = "EnAttente"**
- Identique au formulaire de création

### Détails du projet (`/CitoyenEspace/ProjetDetails/{id}`)
- Affichage complet avec activités
- Affichage du motif de rejet (si Rejeté)
- Boutons Modifier/Supprimer visibles seulement si EnAttente

### Mon profil (`/CitoyenEspace/Profil`)
- Affichage des informations personnelles
- **Formulaire de changement de mot de passe** (ancien + nouveau + confirmer)
- Dernier accès enregistré

---

## 🗄️ Modèles de base de données

```sql
-- Tables principales
Citoyens
├── Id, Nom, Prenom, CIN (UNIQUE)
├── Login (UNIQUE), PasswordHash, Email (UNIQUE)
├── IsActive, CreatedAt, LastLoginAt
├── ResetToken, ResetTokenExpiry
└── 1 → N CitoyenProjets

CitoyenProjets
├── Id, CitoyenId (FK)
├── NomProjet, MatriculeFiscale (UNIQUE), RNE (UNIQUE)
├── TypeProjetId (FK), GouvernoratId (FK), TypeCreateurId (FK)
├── Description, AdresseSociale
├── Statut (EnAttente | Validé | Rejeté)
├── CommentaireAdmin (motif rejet)
├── CreatedAt, UpdatedAt
└── N ← M CitoyenProjetActivites

CitoyenProjetActivites
├── CitoyenProjetId (FK)
├── ActiviteId (FK)
└── EstPrincipale (bool)
```

---

## 🎨 Interface utilisateur

### Sidebar Citoyen (vert tendre #065f46)
- 🏠 Tableau de bord
- 📁 Mes projets
- ➕ Nouveau projet
- ⚙️ Mon profil
- ⏻ Déconnexion

### Page de connexion (onglets)
- **Onglet 1** : Agent / Admin (login existant)
- **Onglet 2** : Espace Citoyen (inscription + connexion)

### Statuts visuels des projets
- 🟡 EnAttente (badge amber)
- 🟢 Validé (badge vert)
- 🔴 Rejeté (badge rouge)

---

## 🔧 Configuration & Migrations

### EF Core Migrations

```bash
cd ErpApp

# Créer la migration
dotnet ef migrations add AddCitoyen

# Appliquer
dotnet ef database update

# Lancer
dotnet run
```

### Seed Data (optionnel pour citoyen de test)
Modifiez `AppDbContext.OnModelCreating()` pour ajouter :
```csharp
m.Entity<Citoyen>().HasData(
    new Citoyen {
        Id = 1,
        Nom = "Ben Ali",
        Prenom = "Ahmed",
        CIN = "12345678",
        Login = "citizen1",
        Email = "citizen@example.tn",
        PasswordHash = BCrypt.Net.BCrypt.HashPassword("Password123"),
        IsActive = true,
        CreatedAt = DateTime.Now
    }
);
```

---

## 📊 Points techniques

### Services utilisés
- **ICitoyenService** — Gestion des comptes citoyens + réinitialisation MDP
- **ICitoyenProjetService** (intégré) — CRUD projets citoyen
- Tous les services géographiques (Gouvernorats, Activités, TypeProjets, etc.)

### Contrôleurs
- **CitoyenAuthController** — Register, Login, ForgotPassword, ResetPassword, Logout
- **CitoyenEspaceController** — Dashboard, MesProjets, NouveauProjet, ModifierProjet, Profil, ChangerMotDePasse

### Sécurité
- Tous les endpoints CitoyenEspace protégés par `[Authorize(Roles = "Citoyen")]`
- Les citoyens ne peuvent voir/modifier que **leurs propres projets**
- Hachage BCrypt pour les mots de passe
- Token de réinitialisation valide 2h
- Vérification CIN + Login/Email pour récupération compte

### Différences Agent/Admin vs Citoyen
| Fonctionnalité | Agent/Admin | Citoyen |
|---|---|---|
| Rôle RBAC | ✅ (Admin, Agent, Consultant) | ❌ (Citoyen auto) |
| Gestion projets | Tous les projets | Ses propres projets seulement |
| Statut projet | EstActif (bool) | Statut (EnAttente/Validé/Rejeté) |
| Suppression | Hard delete | Soft delete (si EnAttente) |
| Historique projets | ✅ HistoriqueProjets | ❌ (à implementer) |

---

## 🚀 Accès

**Page de connexion :** `https://localhost:5001/Auth/Login`

### Compte Agent/Admin
```
Login: admin
Mot de passe: Admin@123
```

### Compte Citoyen (créer un nouveau)
- Cliquer sur l'onglet "Espace Citoyen"
- Cliquer "Créer un compte citoyen"
- Remplir le formulaire d'inscription

---

## 📝 TODO : Améliorations futures

- ✅ Inscription citoyen sans rôle
- ✅ Espace citoyen avec ses projets
- ✅ Modification profil + changement MDP
- ✅ Mot de passe oublié
- ⏳ Notification par email des validations
- ⏳ Historique des projets citoyen
- ⏳ API citoyen (REST)
- ⏳ Upload de fichiers (devis, documents)
- ⏳ Chat citoyen-admin pour clarifications

---

**Version 2.5 — Citoyen intégré — ERP Déclaration © 2026**
