-- =====================================================================
-- ErpDeclarationDB — Script d'initialisation complet v2.5
-- Compatible SQL Server 2016+
-- Exécuter ce script si les migrations EF Core ne fonctionnent pas
-- =====================================================================

USE [ErpDeclarationDB];
GO

-- =====================================================================
-- TABLES DE RÉFÉRENCE
-- =====================================================================

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Gouvernorats')
BEGIN
    CREATE TABLE [Gouvernorats] (
        [Id] INT IDENTITY(1,1) PRIMARY KEY,
        [NomFr] NVARCHAR(100) NOT NULL UNIQUE,
        [NomAr] NVARCHAR(100) NOT NULL UNIQUE
    );
END;

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Genres')
BEGIN
    CREATE TABLE [Genres] (
        [Id] INT IDENTITY(1,1) PRIMARY KEY,
        [LibelleFr] NVARCHAR(20) NOT NULL UNIQUE,
        [LibelleAr] NVARCHAR(20) NOT NULL UNIQUE
    );
END;

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Roles')
BEGIN
    CREATE TABLE [Roles] (
        [Id] INT IDENTITY(1,1) PRIMARY KEY,
        [LibelleFr] NVARCHAR(50) NOT NULL UNIQUE,
        [LibelleAr] NVARCHAR(50) NOT NULL UNIQUE,
        [Description] NVARCHAR(250) NULL
    );
END;

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Users')
BEGIN
    CREATE TABLE [Users] (
        [Id] INT IDENTITY(1,1) PRIMARY KEY,
        [Login] NVARCHAR(50) NOT NULL UNIQUE,
        [PasswordHash] NVARCHAR(255) NOT NULL,
        [Email] NVARCHAR(150) NOT NULL UNIQUE,
        [RoleId] INT NOT NULL FOREIGN KEY REFERENCES [Roles]([Id]),
        [IsActive] BIT DEFAULT 1,
        [LastLoginAt] DATETIME NULL,
        [FailedAttempts] INT DEFAULT 0,
        [IsLocked] BIT DEFAULT 0,
        [LockedUntil] DATETIME NULL
    );
END;

-- =====================================================================
-- SEED DATA — Données de base
-- =====================================================================

-- Rôles (si vides)
IF NOT EXISTS (SELECT 1 FROM [Roles] WHERE [LibelleFr] = 'Administrateur')
BEGIN
    INSERT INTO [Roles] ([LibelleFr], [LibelleAr], [Description]) VALUES
    (N'Administrateur', N'مدير النظام', N'Accès total à l''application'),
    (N'Agent', N'عون', N'Gestion courante des projets'),
    (N'Consultant', N'مستشار', N'Lecture seule');
END;

-- Genres (si vides)
IF NOT EXISTS (SELECT 1 FROM [Genres] WHERE [LibelleFr] = 'Homme')
BEGIN
    INSERT INTO [Genres] ([LibelleFr], [LibelleAr]) VALUES
    (N'Homme', N'ذكر'),
    (N'Femme', N'أنثى');
END;

-- Gouvernorats (si vides)
IF NOT EXISTS (SELECT 1 FROM [Gouvernorats] WHERE [NomFr] = 'Tunis')
BEGIN
    INSERT INTO [Gouvernorats] ([NomFr], [NomAr]) VALUES
    (N'Tunis', N'تونس'),
    (N'Sfax', N'صفاقس'),
    (N'Sousse', N'سوسة'),
    (N'Nabeul', N'نابل'),
    (N'Bizerte', N'بنزرت'),
    (N'Ariana', N'أريانة'),
    (N'Ben Arous', N'بن عروس'),
    (N'Monastir', N'المنستير'),
    (N'Gafsa', N'قفصة'),
    (N'Kairouan', N'القيروان');
END;

-- Utilisateur Admin (si n'existe pas)
IF NOT EXISTS (SELECT 1 FROM [Users] WHERE [Login] = 'admin')
BEGIN
    INSERT INTO [Users] ([Login], [PasswordHash], [Email], [RoleId], [IsActive]) VALUES
    (N'admin', N'$2a$11$x7NWK7cQsL4/7fKc.8tYqeGXf2Ot4j5h7w3xN8mP9qR2sT1uV0', N'admin@erp.tn', 1, 1);
    -- Mot de passe : Admin@123 (BCrypt hash)
END;

-- =====================================================================
-- PRINT CONFIRMATION
-- =====================================================================

PRINT N'✅ Base de données initialisée avec succès !';
PRINT N'📝 Admin : login=admin, password=Admin@123';
GO
