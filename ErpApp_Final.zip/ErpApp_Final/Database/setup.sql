IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'ErpDeclarationDB')
BEGIN
    CREATE DATABASE ErpDeclarationDB;
END
GO

USE ErpDeclarationDB;
GO
-- Module : Géographie
CREATE TABLE Gouvernorats (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Gouvernorats PRIMARY KEY,
    NomFr NVARCHAR(100) NOT NULL CONSTRAINT UQ_Gouvernorats_NomFr UNIQUE,
    NomAr NVARCHAR(100) NOT NULL CONSTRAINT UQ_Gouvernorats_NomAr UNIQUE
);

CREATE TABLE Delegations (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Delegations PRIMARY KEY,
    NomFr NVARCHAR(100) NOT NULL,
    NomAr NVARCHAR(100) NOT NULL,
    GouvernoratId INT NOT NULL CONSTRAINT FK_Delegations_Gouvernorats REFERENCES Gouvernorats(Id),
    CodePostal VARCHAR(10) NOT NULL,
    CONSTRAINT UQ_Delegations_Nom_Gouv_Fr UNIQUE (NomFr, GouvernoratId),
    CONSTRAINT UQ_Delegations_Nom_Gouv_Ar UNIQUE (NomAr, GouvernoratId)
);

CREATE TABLE Administrations (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Administrations PRIMARY KEY,
    NomFr NVARCHAR(150) NOT NULL,
    NomAr NVARCHAR(150) NOT NULL,
    GouvernoratId INT NOT NULL CONSTRAINT FK_Administrations_Gouvernorats REFERENCES Gouvernorats(Id),
    CodeAdministration NVARCHAR(20) NOT NULL CONSTRAINT UQ_Administrations_Code UNIQUE
);

-- Module : Sécurité & RBAC
CREATE TABLE Roles (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Roles PRIMARY KEY,
    LibelleFr NVARCHAR(50) NOT NULL CONSTRAINT UQ_Roles_LibelleFr UNIQUE,
    LibelleAr NVARCHAR(50) NOT NULL CONSTRAINT UQ_Roles_LibelleAr UNIQUE,
    Description NVARCHAR(250) NULL
);

CREATE TABLE Users (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Users PRIMARY KEY,
    Login NVARCHAR(50) NOT NULL CONSTRAINT UQ_Users_Login UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    Email NVARCHAR(150) NOT NULL CONSTRAINT UQ_Users_Email UNIQUE,
    RoleId INT NOT NULL CONSTRAINT FK_Users_Roles REFERENCES Roles(Id),
    IsActive BIT CONSTRAINT DF_Users_IsActive DEFAULT 1,
    LastLoginAt DATETIME NULL,
    FailedAttempts INT CONSTRAINT DF_Users_Failed DEFAULT 0,
    IsLocked BIT CONSTRAINT DF_Users_Locked DEFAULT 0,
    LockedUntil DATETIME NULL
);

CREATE TABLE Permissions (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Permissions PRIMARY KEY,
    Code VARCHAR(50) NOT NULL CONSTRAINT UQ_Permissions_Code UNIQUE,
    LibelleFr NVARCHAR(100) NOT NULL,
    LibelleAr NVARCHAR(100) NOT NULL,
    Module NVARCHAR(50) NOT NULL
);

CREATE TABLE RolePermissions (
    RoleId INT NOT NULL CONSTRAINT FK_RolePermissions_Roles REFERENCES Roles(Id) ON DELETE CASCADE,
    PermissionId INT NOT NULL CONSTRAINT FK_RolePermissions_Permissions REFERENCES Permissions(Id) ON DELETE CASCADE,
    CONSTRAINT PK_RolePermissions PRIMARY KEY (RoleId, PermissionId)
);

-- Module : Configuration & Tiers
CREATE TABLE Genres (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Genres PRIMARY KEY,
    LibelleFr NVARCHAR(20) NOT NULL CONSTRAINT UQ_Genres_LibelleFr UNIQUE,
    LibelleAr NVARCHAR(20) NOT NULL CONSTRAINT UQ_Genres_LibelleAr UNIQUE
);

CREATE TABLE Agents (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Agents PRIMARY KEY,
    Matricule NVARCHAR(15) NOT NULL CONSTRAINT UQ_Agents_Matricule UNIQUE,
    Nom NVARCHAR(100) NOT NULL,
    Prenom NVARCHAR(100) NOT NULL,
    AdministrationId INT NOT NULL CONSTRAINT FK_Agents_Administrations REFERENCES Administrations(Id),
    UserId INT NULL CONSTRAINT FK_Agents_Users REFERENCES Users(Id),
    TelephoneProfessionnel NVARCHAR(20) NULL,
    CONSTRAINT CK_Agents_Matricule_Numeric CHECK (NOT Matricule LIKE '%[^0-9]%')
);

CREATE TABLE Citoyens (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Citoyens PRIMARY KEY,
    Nom NVARCHAR(100) NOT NULL,
    Prenom NVARCHAR(100) NOT NULL,
    GenreId INT NOT NULL CONSTRAINT FK_Citoyens_Genres REFERENCES Genres(Id),
    NomPere NVARCHAR(100) NULL,
    NomGrandPere NVARCHAR(100) NULL,
    NomMere NVARCHAR(100) NULL,
    DateNaissance DATE NULL,
    LieuNaissance NVARCHAR(150) NULL,
    CIN NVARCHAR(20) NOT NULL CONSTRAINT UQ_Citoyens_CIN UNIQUE,
    Telephone NVARCHAR(20) NULL,
    Adresse NVARCHAR(200) NULL,
    UserId INT NULL CONSTRAINT FK_Citoyens_Users REFERENCES Users(Id),
    CreatedAt DATETIME CONSTRAINT DF_Citoyens_CreatedAt DEFAULT GETDATE(),
    CreatedById INT NOT NULL,
    UpdatedAt DATETIME NULL,
    UpdatedById INT NULL,
    AcceptConditions BIT NOT NULL CONSTRAINT DF_Citoyens_Accept DEFAULT 1,
    IsDeleted BIT NOT NULL CONSTRAINT DF_Citoyens_IsDeleted DEFAULT 0,
    DeletedAt DATETIME NULL,
    DeletedById INT NULL
);

-- Module : Configuration Métier
CREATE TABLE Activites (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Activites PRIMARY KEY,
    CodeNACE_Ape NVARCHAR(10) NOT NULL CONSTRAINT UQ_Activites_Code UNIQUE,
    LibelleFr NVARCHAR(150) NOT NULL,
    LibelleAr NVARCHAR(150) NOT NULL
);

CREATE TABLE TypeProjets (
    Id INT IDENTITY(1,1) CONSTRAINT PK_TypeProjets PRIMARY KEY,
    LibelleFr NVARCHAR(50) NOT NULL CONSTRAINT UQ_TypeProjets_Fr UNIQUE,
    LibelleAr NVARCHAR(50) NOT NULL CONSTRAINT UQ_TypeProjets_Ar UNIQUE
);

CREATE TABLE TypeCreateur (
    Id INT IDENTITY(1,1) CONSTRAINT PK_TypeCreateur PRIMARY KEY,
    LibelleFr NVARCHAR(50) NOT NULL CONSTRAINT UQ_TypeCreateur_Fr UNIQUE,
    LibelleAr NVARCHAR(50) NOT NULL CONSTRAINT UQ_TypeCreateur_Ar UNIQUE
);

-- Module : Cœur Métier (Projets)
CREATE TABLE Projets (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Projets PRIMARY KEY,
    NumeroProjet NVARCHAR(30) NULL CONSTRAINT UQ_Projets_Numero UNIQUE,
    CitoyenId INT NOT NULL CONSTRAINT FK_Projets_Citoyens REFERENCES Citoyens(Id),
    GouvernoratId INT NOT NULL CONSTRAINT FK_Projets_Gouvernorats REFERENCES Gouvernorats(Id),
    TypeProjetId INT NOT NULL CONSTRAINT FK_Projets_TypeProjets REFERENCES TypeProjets(Id),
    TypeCreateurId INT NOT NULL CONSTRAINT FK_Projets_TypeCreateur REFERENCES TypeCreateur(Id),
    NomProjet NVARCHAR(150) NOT NULL,
    Description NVARCHAR(500) NULL,
    MatriculeFiscale NVARCHAR(20) NOT NULL CONSTRAINT UQ_Projets_MF UNIQUE,
    RNE NVARCHAR(20) NOT NULL CONSTRAINT UQ_Projets_RNE UNIQUE,
    AdresseSociale NVARCHAR(200) NULL,
    EstActif BIT CONSTRAINT DF_Projets_Actif DEFAULT 1,
    CreatedAt DATETIME CONSTRAINT DF_Projets_Created DEFAULT GETDATE(),
    CreatedById INT NOT NULL,
    UpdatedAt DATETIME NULL,
    UpdatedById INT NULL,
    IsDeleted BIT CONSTRAINT DF_Projets_Deleted DEFAULT 0,
    DeletedAt DATETIME NULL,
    DeletedById INT NULL
);

CREATE TABLE HistoriqueProjets (
    LogId INT IDENTITY(1,1) CONSTRAINT PK_HistoriqueProjets PRIMARY KEY,
    ProjetId INT NOT NULL CONSTRAINT FK_Historique_Projets REFERENCES Projets(Id),
    AncienNumeroProjet NVARCHAR(30) NULL,
    AncienCitoyenId INT NOT NULL,
    AncienGouvernoratId INT NOT NULL,
    AncienTypeProjetId INT NOT NULL,
    AncienTypeCreateurId INT NOT NULL,
    AncienNomProjet NVARCHAR(150) NOT NULL,
    AncienneDescription NVARCHAR(500) NULL,
    AncienneMatriculeFiscale NVARCHAR(20) NOT NULL,
    AncienRNE NVARCHAR(20) NOT NULL,
    AncienneAdresseSociale NVARCHAR(200) NULL,
    AncienEstActif BIT NOT NULL,
    AncienCreatedAt DATETIME NOT NULL,
    AncienCreatedById INT NOT NULL,
    AncienUpdatedAt DATETIME NULL,
    AncienUpdatedById INT NULL,
    DateModification DATETIME CONSTRAINT DF_HistoriqueProjets_Date DEFAULT GETDATE(),
    ModifieById INT NULL CONSTRAINT FK_HistoriqueProjets_Users REFERENCES Users(Id)
);

-- Extensions Métier
CREATE TABLE ProjetActivites (
    ProjetId INT NOT NULL CONSTRAINT FK_ProjetActivites_Projets REFERENCES Projets(Id),
    ActiviteId INT NOT NULL CONSTRAINT FK_ProjetActivites_Activites REFERENCES Activites(Id),
    EstPrincipale BIT CONSTRAINT DF_ProjetActivites_Prp DEFAULT 0,
    CONSTRAINT PK_ProjetActivites PRIMARY KEY (ProjetId, ActiviteId)
);

CREATE TABLE TypeLocaux (
    Id INT IDENTITY(1,1) CONSTRAINT PK_TypeLocaux PRIMARY KEY,
    LibelleFr NVARCHAR(50) NOT NULL CONSTRAINT UQ_TypeLocaux_Fr UNIQUE,
    LibelleAr NVARCHAR(50) NOT NULL CONSTRAINT UQ_TypeLocaux_Ar UNIQUE
);

CREATE TABLE Locaux (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Locaux PRIMARY KEY,
    ProjetId INT NOT NULL CONSTRAINT FK_Locaux_Projets REFERENCES Projets(Id),
    TypeLocalId INT NOT NULL CONSTRAINT FK_Locaux_TypeLocaux REFERENCES TypeLocaux(Id),
    DelegationId INT NOT NULL CONSTRAINT FK_Locaux_Delegations REFERENCES Delegations(Id),
    Adresse NVARCHAR(200) NOT NULL,
    Surface DECIMAL(10,2) NOT NULL,
    CONSTRAINT CK_Locaux_Surface_Positive CHECK (Surface > 0)
);
GO

/* ==========================================================================
   SECTION 2 : INDEXATION & OPTIMISATION
   ========================================================================== */
PRINT '--> Étape 4 : Déploiement des index de performance...';

CREATE INDEX IX_Projets_CitoyenId ON Projets(CitoyenId);
CREATE INDEX IX_Projets_GouvernoratId ON Projets(GouvernoratId);
CREATE INDEX IX_Locaux_ProjetId ON Locaux(ProjetId);
CREATE INDEX IX_HistoriqueProjets_ProjetId ON HistoriqueProjets(ProjetId);
GO

/* ==========================================================================
   SECTION 3 : VUES APPLICATIVES BILINGUES & SECURITÉ
   ========================================================================== */
PRINT '--> Étape 5 : Déploiement des vues unifiées (FR/AR & RBAC)...';
GO
CREATE VIEW V_Citoyens_Actifs AS
SELECT 
    c.Id, c.Nom, c.Prenom, c.NomPere, c.NomGrandPere, c.NomMere, c.DateNaissance, 
    c.LieuNaissance, c.CIN, c.Telephone, c.Adresse, c.UserId, c.CreatedAt, c.CreatedById,
    c.GenreId, g.LibelleFr AS GenreLibelleFr, g.LibelleAr AS GenreLibelleAr
FROM Citoyens c
INNER JOIN Genres g ON c.GenreId = g.Id
WHERE c.IsDeleted = 0;
GO

CREATE VIEW V_Projets_Actifs AS
SELECT 
    p.Id, p.NumeroProjet, p.NomProjet, p.Description, p.MatriculeFiscale, p.RNE, p.AdresseSociale, p.EstActif, p.CreatedAt,
    c.Nom AS CitoyenNom, c.Prenom AS CitoyenPrenom,
    g.NomFr AS GouvernoratFr, g.NomAr AS GouvernoratAr,
    tp.LibelleFr AS TypeProjetFr, tp.LibelleAr AS TypeProjetAr,
    tc.LibelleFr AS TypeCreateurFr, tc.LibelleAr AS TypeCreateurAr
FROM Projets p
INNER JOIN Citoyens c ON p.CitoyenId = c.Id
INNER JOIN Gouvernorats g ON p.GouvernoratId = g.Id
INNER JOIN TypeProjets tp ON p.TypeProjetId = tp.Id
INNER JOIN TypeCreateur tc ON p.TypeCreateurId = tc.Id
WHERE p.IsDeleted = 0;
GO

CREATE VIEW V_User_Permissions AS
SELECT 
    u.Id AS UserId, u.Login, u.IsActive, u.IsLocked,
    r.Id AS RoleId, r.LibelleFr AS RoleLibelleFr, r.LibelleAr AS RoleLibelleAr,
    p.Id AS PermissionId, p.Code AS PermissionCode, p.Module
FROM Users u
INNER JOIN Roles r ON u.RoleId = r.Id
INNER JOIN RolePermissions rp ON r.Id = rp.RoleId
INNER JOIN Permissions p ON rp.PermissionId = p.Id;
GO

/* ==========================================================================
   SECTION 4 : AUTOMATISATION ET TRIGGERS
   ========================================================================== */
PRINT '--> Étape 6 : Déploiement des triggers opérationnels...';
GO
CREATE TRIGGER TR_Projets_GenerateNumero
ON Projets
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Projets
    SET NumeroProjet = 'PRJ-' + CAST(YEAR(GETDATE()) AS VARCHAR(4)) + '-' + RIGHT('000000' + CAST(p.Id AS VARCHAR(6)), 6)
    FROM Projets p
    INNER JOIN inserted i ON p.Id = i.Id;
END;
GO

CREATE TRIGGER TR_Projets_TrackChanges
ON Projets
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF UPDATE(NomProjet) OR UPDATE(Description) OR UPDATE(EstActif) OR UPDATE(AdresseSociale) 
       OR UPDATE(CitoyenId) OR UPDATE(GouvernoratId) OR UPDATE(TypeProjetId) OR UPDATE(MatriculeFiscale) OR UPDATE(RNE)
    BEGIN
        DECLARE @ContextUser INT = TRY_CAST(SESSION_CONTEXT(N'CurrentUserId') AS INT);
        IF @ContextUser IS NULL SELECT @ContextUser = i.UpdatedById FROM inserted i;

        INSERT INTO HistoriqueProjets (
            ProjetId, AncienNumeroProjet, AncienCitoyenId, AncienGouvernoratId, AncienTypeProjetId, AncienTypeCreateurId,
            AncienNomProjet, AncienneDescription, AncienneMatriculeFiscale, AncienRNE, AncienneAdresseSociale, 
            AncienEstActif, AncienCreatedAt, AncienCreatedById, AncienUpdatedAt, AncienUpdatedById, DateModification, ModifieById
        )
        SELECT 
            d.Id, d.NumeroProjet, d.CitoyenId, d.GouvernoratId, d.TypeProjetId, d.TypeCreateurId,
            d.NomProjet, d.Description, d.MatriculeFiscale, d.RNE, d.AdresseSociale, 
            d.EstActif, d.CreatedAt, d.CreatedById, d.UpdatedAt, d.UpdatedById, GETDATE(), @ContextUser
        FROM deleted d INNER JOIN inserted i ON d.Id = i.Id;
    END
END;
GO

CREATE TRIGGER TR_Projets_OnDelete
ON Projets
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @ContextUser INT = TRY_CAST(SESSION_CONTEXT(N'CurrentUserId') AS INT);
    UPDATE Projets SET IsDeleted = 1, EstActif = 0, DeletedAt = GETDATE(), DeletedById = @ContextUser
    FROM Projets p INNER JOIN deleted d ON p.Id = d.Id;
END;
GO

/* ==========================================================================
   SECTION 5 : CRUD BILINGUE & SÉCURITÉ (PROCÉDURES STOCKÉES)
   ========================================================================== */
PRINT '--> Étape 7 : Compilation des procédures stockées multilingues...';
GO
-- 1. Genres
CREATE PROCEDURE sp_Genres_CRUD
    @Action VARCHAR(10), @Id INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @Action = 'SELECT' BEGIN
        IF @Id IS NULL SELECT Id, LibelleFr, LibelleAr FROM Genres ORDER BY LibelleFr;
        ELSE SELECT Id, LibelleFr, LibelleAr FROM Genres WHERE Id = @Id;
    END
END;
GO

-- 2. Gouvernorats
CREATE PROCEDURE sp_Gouvernorats_CRUD
    @Action VARCHAR(10), @Id INT = NULL, @NomFr NVARCHAR(100) = NULL, @NomAr NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF @Action = 'CREATE' BEGIN INSERT INTO Gouvernorats (NomFr, NomAr) VALUES (@NomFr, @NomAr); SELECT SCOPE_IDENTITY() AS NewId; END
        ELSE IF @Action = 'SELECT' BEGIN IF @Id IS NULL SELECT Id, NomFr, NomAr FROM Gouvernorats ORDER BY NomFr; ELSE SELECT Id, NomFr, NomAr FROM Gouvernorats WHERE Id = @Id; END
        ELSE IF @Action = 'UPDATE' UPDATE Gouvernorats SET NomFr = @NomFr, NomAr = @NomAr WHERE Id = @Id;
        ELSE IF @Action = 'DELETE' DELETE FROM Gouvernorats WHERE Id = @Id;
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION; THROW; END CATCH
END;
GO

-- 3. Delegations
CREATE PROCEDURE sp_Delegations_CRUD
    @Action VARCHAR(10), @Id INT = NULL, @NomFr NVARCHAR(100) = NULL, @NomAr NVARCHAR(100) = NULL, @GouvernoratId INT = NULL, @CodePostal VARCHAR(10) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF @Action = 'CREATE' BEGIN INSERT INTO Delegations (NomFr, NomAr, GouvernoratId, CodePostal) VALUES (@NomFr, @NomAr, @GouvernoratId, @CodePostal); SELECT SCOPE_IDENTITY() AS NewId; END
        ELSE IF @Action = 'SELECT' BEGIN IF @Id IS NULL SELECT Id, NomFr, NomAr, GouvernoratId, CodePostal FROM Delegations ORDER BY NomFr; ELSE SELECT Id, NomFr, NomAr, GouvernoratId, CodePostal FROM Delegations WHERE Id = @Id; END
        ELSE IF @Action = 'UPDATE' UPDATE Delegations SET NomFr = @NomFr, NomAr = @NomAr, GouvernoratId = @GouvernoratId, CodePostal = @CodePostal WHERE Id = @Id;
        ELSE IF @Action = 'DELETE' DELETE FROM Delegations WHERE Id = @Id;
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION; THROW; END CATCH
END;
GO

-- 4. Administrations
CREATE PROCEDURE sp_Administrations_CRUD
    @Action VARCHAR(10), @Id INT = NULL, @NomFr NVARCHAR(150) = NULL, @NomAr NVARCHAR(150) = NULL, @GouvernoratId INT = NULL, @CodeAdministration NVARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF @Action = 'CREATE' BEGIN INSERT INTO Administrations (NomFr, NomAr, GouvernoratId, CodeAdministration) VALUES (@NomFr, @NomAr, @GouvernoratId, @CodeAdministration); SELECT SCOPE_IDENTITY() AS NewId; END
        ELSE IF @Action = 'SELECT' BEGIN IF @Id IS NULL SELECT Id, NomFr, NomAr, GouvernoratId, CodeAdministration FROM Administrations; ELSE SELECT Id, NomFr, NomAr, GouvernoratId, CodeAdministration FROM Administrations WHERE Id = @Id; END
        ELSE IF @Action = 'UPDATE' UPDATE Administrations SET NomFr = @NomFr, NomAr = @NomAr, GouvernoratId = @GouvernoratId, CodeAdministration = @CodeAdministration WHERE Id = @Id;
        ELSE IF @Action = 'DELETE' DELETE FROM Administrations WHERE Id = @Id;
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION; THROW; END CATCH
END;
GO

-- 5. Roles
CREATE PROCEDURE sp_Roles_CRUD
    @Action VARCHAR(10), @Id INT = NULL, @LibelleFr NVARCHAR(50) = NULL, @LibelleAr NVARCHAR(50) = NULL, @Description NVARCHAR(250) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF @Action = 'CREATE' BEGIN INSERT INTO Roles (LibelleFr, LibelleAr, Description) VALUES (@LibelleFr, @LibelleAr, @Description); SELECT SCOPE_IDENTITY() AS NewId; END
        ELSE IF @Action = 'SELECT' BEGIN IF @Id IS NULL SELECT Id, LibelleFr, LibelleAr, Description FROM Roles; ELSE SELECT Id, LibelleFr, LibelleAr, Description FROM Roles WHERE Id = @Id; END
        ELSE IF @Action = 'UPDATE' UPDATE Roles SET LibelleFr = @LibelleFr, LibelleAr = @LibelleAr, Description = @Description WHERE Id = @Id;
        ELSE IF @Action = 'DELETE' DELETE FROM Roles WHERE Id = @Id;
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION; THROW; END CATCH
END;
GO

-- 6. Users
CREATE PROCEDURE sp_Users_CRUD
    @Action VARCHAR(10), @Id INT = NULL, @Login NVARCHAR(50) = NULL, @PasswordHash NVARCHAR(255) = NULL, @Email NVARCHAR(150) = NULL, @RoleId INT = NULL, @IsActive BIT = NULL, @ResetLock BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF @Action = 'CREATE' BEGIN INSERT INTO Users (Login, PasswordHash, Email, RoleId, IsActive) VALUES (@Login, @PasswordHash, @Email, @RoleId, ISNULL(@IsActive, 1)); SELECT SCOPE_IDENTITY() AS NewId; END
        ELSE IF @Action = 'SELECT' BEGIN IF @Id IS NULL SELECT Id, Login, Email, RoleId, IsActive, LastLoginAt, IsLocked FROM Users; ELSE SELECT Id, Login, Email, RoleId, IsActive, LastLoginAt, IsLocked FROM Users WHERE Id = @Id; END
        ELSE IF @Action = 'UPDATE' BEGIN UPDATE Users SET Email = ISNULL(@Email, Email), RoleId = ISNULL(@RoleId, RoleId), IsActive = ISNULL(@IsActive, IsActive), FailedAttempts = CASE WHEN @ResetLock = 1 THEN 0 ELSE FailedAttempts END, IsLocked = CASE WHEN @ResetLock = 1 THEN 0 ELSE IsLocked END, LockedUntil = CASE WHEN @ResetLock = 1 THEN NULL ELSE LockedUntil END WHERE Id = @Id; END
        ELSE IF @Action = 'DELETE' DELETE FROM Users WHERE Id = @Id;
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION; THROW; END CATCH
END;
GO

-- 7. Permissions Access Control Engine
CREATE PROCEDURE sp_Users_GetPermissions
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT PermissionCode 
    FROM V_User_Permissions
    WHERE UserId = @UserId AND IsActive = 1 AND IsLocked = 0;
END;
GO

-- 8. Agents
CREATE PROCEDURE sp_Agents_CRUD
    @Action VARCHAR(10), @Id INT = NULL, @Matricule NVARCHAR(15) = NULL, @Nom NVARCHAR(100) = NULL, @Prenom NVARCHAR(100) = NULL, @AdministrationId INT = NULL, @UserId INT = NULL, @TelephoneProfessionnel NVARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF @Action = 'CREATE' BEGIN INSERT INTO Agents (Matricule, Nom, Prenom, AdministrationId, UserId, TelephoneProfessionnel) VALUES (@Matricule, @Nom, @Prenom, @AdministrationId, @UserId, @TelephoneProfessionnel); SELECT SCOPE_IDENTITY() AS NewId; END
        ELSE IF @Action = 'SELECT' BEGIN IF @Id IS NULL SELECT Id, Matricule, Nom, Prenom, AdministrationId, UserId, TelephoneProfessionnel FROM Agents; ELSE SELECT Id, Matricule, Nom, Prenom, AdministrationId, UserId, TelephoneProfessionnel FROM Agents WHERE Id = @Id; END
        ELSE IF @Action = 'UPDATE' UPDATE Agents SET Matricule = @Matricule, Nom = @Nom, Prenom = @Prenom, AdministrationId = @AdministrationId, UserId = @UserId, TelephoneProfessionnel = @TelephoneProfessionnel WHERE Id = @Id;
        ELSE IF @Action = 'DELETE' DELETE FROM Agents WHERE Id = @Id;
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION; THROW; END CATCH
END;
GO

-- 9. Citoyens
CREATE PROCEDURE sp_Citoyens_CRUD
    @Action VARCHAR(10), @Id INT = NULL, @Nom NVARCHAR(100) = NULL, @Prenom NVARCHAR(100) = NULL, @GenreId INT = NULL, @NomPere NVARCHAR(100) = NULL, @NomGrandPere NVARCHAR(100) = NULL, @NomMere NVARCHAR(100) = NULL, @DateNaissance DATE = NULL, @LieuNaissance NVARCHAR(150) = NULL, @CIN NVARCHAR(20) = NULL, @Telephone NVARCHAR(20) = NULL, @Adresse NVARCHAR(200) = NULL, @UserId INT = NULL, @CreatedById INT = NULL, @UpdatedById INT = NULL, @AcceptConditions BIT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF @Action = 'CREATE' BEGIN INSERT INTO Citoyens (Nom, Prenom, GenreId, NomPere, NomGrandPere, NomMere, DateNaissance, LieuNaissance, CIN, Telephone, Adresse, UserId, CreatedById, AcceptConditions) VALUES (@Nom, @Prenom, @GenreId, @NomPere, @NomGrandPere, @NomMere, @DateNaissance, @LieuNaissance, @CIN, @Telephone, @Adresse, @UserId, @CreatedById, ISNULL(@AcceptConditions, 1)); SELECT SCOPE_IDENTITY() AS NewId; END
        ELSE IF @Action = 'SELECT' BEGIN IF @Id IS NULL SELECT * FROM V_Citoyens_Actifs ORDER BY Nom, Prenom; ELSE SELECT * FROM V_Citoyens_Actifs WHERE Id = @Id; END
        ELSE IF @Action = 'UPDATE' UPDATE Citoyens SET Nom = @Nom, Prenom = @Prenom, GenreId = ISNULL(@GenreId, GenreId), NomPere = @NomPere, NomGrandPere = @NomGrandPere, NomMere = @NomMere, DateNaissance = @DateNaissance, LieuNaissance = @LieuNaissance, Telephone = @Telephone, Adresse = @Adresse, UpdatedById = @UpdatedById, UpdatedAt = GETDATE(), AcceptConditions = ISNULL(@AcceptConditions, AcceptConditions) WHERE Id = @Id;
        ELSE IF @Action = 'DELETE' DELETE FROM Citoyens WHERE Id = @Id;
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION; THROW; END CATCH
END;
GO

-- 10. Soft Delete Citoyens
CREATE PROCEDURE sp_Citoyens_Delete
    @Id INT, @DeletedById INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Citoyens SET IsDeleted = 1, DeletedAt = GETDATE(), DeletedById = @DeletedById WHERE Id = @Id;
END;
GO

-- 11. Activités
CREATE PROCEDURE sp_Activites_CRUD
    @Action VARCHAR(10), @Id INT = NULL, @CodeNACE_Ape NVARCHAR(10) = NULL, @LibelleFr NVARCHAR(150) = NULL, @LibelleAr NVARCHAR(150) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF @Action = 'CREATE' BEGIN INSERT INTO Activites (CodeNACE_Ape, LibelleFr, LibelleAr) VALUES (@CodeNACE_Ape, @LibelleFr, @LibelleAr); SELECT SCOPE_IDENTITY() AS NewId; END
        ELSE IF @Action = 'SELECT' BEGIN IF @Id IS NULL SELECT Id, CodeNACE_Ape, LibelleFr, LibelleAr FROM Activites ORDER BY LibelleFr; ELSE SELECT Id, CodeNACE_Ape, LibelleFr, LibelleAr FROM Activites WHERE Id = @Id; END
        ELSE IF @Action = 'UPDATE' UPDATE Activites SET CodeNACE_Ape = @CodeNACE_Ape, LibelleFr = @LibelleFr, LibelleAr = @LibelleAr WHERE Id = @Id;
        ELSE IF @Action = 'DELETE' DELETE FROM Activites WHERE Id = @Id;
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION; THROW; END CATCH
END;
GO

-- 12. Projets (Avec contexte utilisateur)
CREATE PROCEDURE sp_Projets_CRUD
    @Action VARCHAR(10), @Id INT = NULL, @CitoyenId INT = NULL, @GouvernoratId INT = NULL, @TypeProjetId INT = NULL, @TypeCreateurId INT = NULL, @NomProjet NVARCHAR(150) = NULL, @Description NVARCHAR(500) = NULL, @MatriculeFiscale NVARCHAR(20) = NULL, @RNE NVARCHAR(20) = NULL, @AdresseSociale NVARCHAR(200) = NULL, @EstActif BIT = NULL, @CurrentUserId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF @CurrentUserId IS NOT NULL EXEC sys.sp_set_session_context @key = N'CurrentUserId', @value = @CurrentUserId;

        IF @Action = 'CREATE' BEGIN
            INSERT INTO Projets (CitoyenId, GouvernoratId, TypeProjetId, TypeCreateurId, NomProjet, Description, MatriculeFiscale, RNE, AdresseSociale, CreatedById, EstActif)
            VALUES (@CitoyenId, @GouvernoratId, @TypeProjetId, @TypeCreateurId, @NomProjet, @Description, @MatriculeFiscale, @RNE, @AdresseSociale, @CurrentUserId, ISNULL(@EstActif, 1));
            SELECT SCOPE_IDENTITY() AS NewId;
        END
        ELSE IF @Action = 'SELECT' BEGIN IF @Id IS NULL SELECT * FROM V_Projets_Actifs ORDER BY CreatedAt DESC; ELSE SELECT * FROM V_Projets_Actifs WHERE Id = @Id; END
        ELSE IF @Action = 'UPDATE' BEGIN
            UPDATE Projets SET CitoyenId = ISNULL(@CitoyenId, CitoyenId), GouvernoratId = ISNULL(@GouvernoratId, GouvernoratId), TypeProjetId = ISNULL(@TypeProjetId, TypeProjetId), NomProjet = @NomProjet, Description = @Description, AdresseSociale = @AdresseSociale, EstActif = @EstActif, UpdatedById = @CurrentUserId, UpdatedAt = GETDATE() WHERE Id = @Id AND IsDeleted = 0;
        END
        ELSE IF @Action = 'DELETE' BEGIN DELETE FROM Projets WHERE Id = @Id; END
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION; THROW; END CATCH
END;
GO

-- 13. Locaux
CREATE PROCEDURE sp_Locaux_CRUD
    @Action VARCHAR(10), @Id INT = NULL, @ProjetId INT = NULL, @TypeLocalId INT = NULL, @DelegationId INT = NULL, @Adresse NVARCHAR(200) = NULL, @Surface DECIMAL(10,2) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF @Action = 'CREATE' BEGIN INSERT INTO Locaux (ProjetId, TypeLocalId, DelegationId, Adresse, Surface) VALUES (@ProjetId, @TypeLocalId, @DelegationId, @Adresse, @Surface); SELECT SCOPE_IDENTITY() AS NewId; END
        ELSE IF @Action = 'SELECT' BEGIN IF @Id IS NULL SELECT Id, ProjetId, TypeLocalId, DelegationId, Adresse, Surface FROM Locaux; ELSE SELECT Id, ProjetId, TypeLocalId, DelegationId, Adresse, Surface FROM Locaux WHERE Id = @Id; END
        ELSE IF @Action = 'UPDATE' UPDATE Locaux SET TypeLocalId = @TypeLocalId, DelegationId = @DelegationId, Adresse = @Adresse, Surface = @Surface WHERE Id = @Id;
        ELSE IF @Action = 'DELETE' DELETE FROM Locaux WHERE Id = @Id;
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION; THROW; END CATCH
END;
GO

-- 14. Moteur de Recherche Global et Paginé (Optimisé Bilingue)
CREATE PROCEDURE sp_V_Projets_Actifs_GetPaged_V2
    @SearchTerm NVARCHAR(100) = NULL, @PageNumber INT = 1, @PageSize INT = 10
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT COUNT(*) AS TotalRows FROM V_Projets_Actifs
    WHERE (@SearchTerm IS NULL OR NomProjet LIKE '%' + @SearchTerm + '%' OR NumeroProjet LIKE '%' + @SearchTerm + '%' OR MatriculeFiscale LIKE '%' + @SearchTerm + '%')
    OPTION (RECOMPILE);

    SELECT Id, NumeroProjet, NomProjet, Description, MatriculeFiscale, RNE, AdresseSociale, EstActif, CreatedAt, CitoyenNom, CitoyenPrenom, 
           GouvernoratFr, GouvernoratAr, TypeProjetFr, TypeProjetAr, TypeCreateurFr, TypeCreateurAr
    FROM V_Projets_Actifs
    WHERE (@SearchTerm IS NULL OR NomProjet LIKE '%' + @SearchTerm + '%' OR NumeroProjet LIKE '%' + @SearchTerm + '%' OR MatriculeFiscale LIKE '%' + @SearchTerm + '%')
    ORDER BY CreatedAt DESC OFFSET (@PageNumber - 1) * @PageSize ROWS FETCH NEXT @PageSize ROWS ONLY
    OPTION (RECOMPILE);
END;
GO

/* ==========================================================================
   SECTION 6 : INJECTION DES DONNÉES DE RÉFÉRENCE BILINGUES (SEED DATA)
   ========================================================================== */
PRINT '--> Étape 8 : Injection des données de référence (Français / Arabe)...';

-- Genres initiaux
INSERT INTO Genres (LibelleFr, LibelleAr) VALUES ('Homme', N'ذكر'), ('Femme', N'أنثى');

-- Types de Créateurs standards
INSERT INTO TypeCreateur (LibelleFr, LibelleAr) VALUES ('Personne Physique', N'شخص طبيعي'), ('Personne Morale', N'شخص معنوي');

-- Types de Projets par défaut
INSERT INTO TypeProjets (LibelleFr, LibelleAr) VALUES 
('Industriel', N'صناعي'), ('Commercial', N'تجاري'), ('Service', N'خدماتي'), ('Agricole', N'فلاحي');

-- Exemple de Gouvernorat (Tunisie)
INSERT INTO Gouvernorats (NomFr, NomAr) VALUES ('Sfax', N'صفاقس'), ('Tunis', N'تونس'), ('Sousse', N'سوسة');

-- Injection Sécurisée des Rôles
SET IDENTITY_INSERT Roles ON;
INSERT INTO Roles (Id, LibelleFr, LibelleAr, Description) VALUES 
(1, 'Administrateur', N'مدير النظام', 'Accès total à toutes les fonctionnalités'),
(2, 'Agent Administration', N'عون إدارة', 'Gestion opérationnelle des dossiers citoyens et projets');
SET IDENTITY_INSERT Roles OFF;

-- Injection des Permissions Métier (Citoyen Terminology)
INSERT INTO Permissions (Code, LibelleFr, LibelleAr, Module) VALUES 
('CITOYEN_CREATE', 'Créer un citoyen', N'إنشاء مواطن', 'Citoyens'),
('CITOYEN_UPDATE', 'Modifier un citoyen', N'تعديل مواطن', 'Citoyens'),
('CITOYEN_DELETE', 'Supprimer un citoyen', N'حذف مواطن', 'Citoyens'),
('PROJET_CREATE',  'Créer un projet', N'إنشاء مشروع', 'Projets'),
('PROJET_UPDATE',  'Modifier un projet', N'تعديل مشروع', 'Projets'),
('PROJET_DELETE',  'Supprimer un projet', N'حذف مشروع', 'Projets'),
('CONFIG_GEOGRAPHY', 'Gérer la géographie', N'إدارة الجغرافيا', 'Configuration');

-- Liaisons Rôles <-> Permissions (RBAC)
-- Administrateur (Id: 1) -> Tout est autorisé
INSERT INTO RolePermissions (RoleId, PermissionId) SELECT 1, Id FROM Permissions;

-- Agent Administration (Id: 2) -> Lecture/Écriture uniquement (Pas de suppression)
INSERT INTO RolePermissions (RoleId, PermissionId) 
SELECT 2, Id FROM Permissions WHERE Code IN ('CITOYEN_CREATE', 'CITOYEN_UPDATE', 'PROJET_CREATE', 'PROJET_UPDATE');
GO

PRINT '======================================================================';
PRINT '   🚀 [SUCCESS] : Base unifiée v2.6 CITOYEN & RBAC Déployée !        ';
PRINT '======================================================================';