# 🏛️ ERP Déclaration — Solution ASP.NET Core 8 MVC

**Version 2.5 — Bilingue Français / عربي**

Application ERP complète de gestion des déclarations de projets, clients, agents et géographie administrative.

---

## ✨ Fonctionnalités complètes

| Module | Fonctionnalités |
|--------|----------------|
| 🏠 **Dashboard** | Statistiques temps réel, derniers projets/clients, répartition par type et gouvernorat |
| 📁 **Projets** | CRUD complet, numérotation auto (PRJ-YYYY-XXXXXX), activités NACE, locaux, historique |
| 👤 **Clients** | CRUD + soft delete, filtre par genre, fiche détaillée avec projets liés |
| 🧑‍💼 **Agents** | CRUD, lien avec utilisateur système, administration d'appartenance |
| 🗺️ **Géographie** | Gouvernorats, Délégations (cascade), Administrations — tous bilingues FR/AR |
| ⚙️ **Activités** | Codes NACE/APE bilingues, liaison Many-to-Many avec projets |
| 🔐 **Sécurité** | Authentification par cookie, rôles RBAC, verrouillage compte |
| 👥 **Utilisateurs** | CRUD, hashage BCrypt, gestion des rôles |
| 📜 **Historique** | Traçabilité automatique des modifications de projets (via trigger EF) |

---

## 🛠️ Prérequis

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- SQL Server (LocalDB inclus avec Visual Studio, ou SQL Server Express)
- Visual Studio 2022 / VS Code / Rider

---

## 🚀 Démarrage rapide

### Option A — EF Core Migrations (recommandée)

```bash
cd ErpApp

# Installer les outils EF (si pas déjà fait)
dotnet tool install --global dotnet-ef

# Créer et appliquer les migrations
dotnet ef migrations add InitialCreate
dotnet ef database update

# Lancer l'application
dotnet run
```

L'application démarre sur `https://localhost:5001`

**Compte par défaut :** `admin` / `Admin@123`

### Option B — Script SQL manuel

Exécuter `Database/setup.sql` dans **SSMS** ou **Azure Data Studio**, puis lancer l'application.
> Note : avec cette option, créez manuellement l'utilisateur admin via l'interface après le premier lancement.

---

## ⚙️ Configuration de la connexion

Modifier `appsettings.json` selon votre environnement :

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=ErpDeclarationDB;Trusted_Connection=True;TrustServerCertificate=True"
}
```

**SQL Server Express :**
```
Server=.\\SQLEXPRESS;Database=ErpDeclarationDB;Trusted_Connection=True;TrustServerCertificate=True
```

**Avec authentification SQL :**
```
Server=monServeur;Database=ErpDeclarationDB;User Id=user;Password=pass;TrustServerCertificate=True
```

---

## 📁 Structure du projet

```
ErpApp/
├── Controllers/
│   └── Controllers.cs          # Tous les contrôleurs (Auth, Home, Projets, Clients, Agents…)
├── Models/
│   └── Models.cs               # Toutes les entités + ViewModels
├── Services/
│   └── Services.cs             # Interfaces + implémentations (logique métier)
├── Data/
│   └── AppDbContext.cs         # EF Core DbContext + seed data
├── Views/
│   ├── Auth/Login.cshtml       # Page de connexion
│   ├── Home/Index.cshtml       # Dashboard
│   ├── Projets/                # Index, Create, Edit, Details, AddLocal
│   ├── Clients/                # Index, Create, Edit, Details
│   ├── Agents/                 # Index, Create, Edit, Details
│   ├── Gouvernorats/           # Index, Create, Edit
│   ├── Delegations/            # Index, Create, Edit
│   ├── Administrations/        # Index, Create, Edit
│   ├── Activites/              # Index, Create, Edit
│   ├── Roles/                  # Index, Create, Edit
│   ├── Users/                  # Index, Create, Edit
│   └── Shared/_Layout.cshtml   # Layout principal avec sidebar
├── wwwroot/
│   ├── css/app.css             # Design moderne complet
│   └── js/app.js               # Interactivité (modales, tabs, cascade délégations)
├── Database/
│   └── setup.sql               # Script SQL complet alternatif
└── appsettings.json
```

---

## 🗄️ Architecture base de données

### Tables principales
| Table | Description |
|-------|-------------|
| `Gouvernorats` | Gouvernorats bilingues FR/AR |
| `Delegations` | Délégations par gouvernorat + code postal |
| `Administrations` | Administrations publiques par gouvernorat |
| `Roles` | Rôles RBAC bilingues |
| `Users` | Utilisateurs avec hash BCrypt |
| `Genres` | Genres bilingues (Homme/ذكر, Femme/أنثى) |
| `Agents` | Agents liés à une administration |
| `Clients` | Clients avec soft delete |
| `Activites` | Codes NACE/APE bilingues |
| `TypeProjets` | Types de projets bilingues |
| `TypeCreateur` | Types de créateurs bilingues |
| `TypeLocaux` | Types de locaux bilingues |
| `Projets` | Projets avec numérotation auto + soft delete |
| `ProjetActivites` | Liaison N-N projets ↔ activités + activité principale |
| `Locaux` | Locaux physiques liés à un projet |
| `HistoriqueProjets` | Traçabilité complète des modifications |

### Vues SQL
- `V_Clients_Actifs` — Clients non supprimés avec libellé de genre bilingue
- `V_Projets_Actifs` — Projets non supprimés avec toutes les jointures

### Triggers SQL
- `TR_Projets_GenerateNumero` — Génère `PRJ-YYYY-XXXXXX` après INSERT
- `TR_Projets_TrackChanges` — Historise les modifications dans `HistoriqueProjets`

---

## 🔐 Sécurité

- Authentification par cookie ASP.NET Core
- Mots de passe hashés avec **BCrypt** (salt automatique)
- Protection CSRF sur tous les formulaires (`[ValidateAntiForgeryToken]`)
- Toutes les routes protégées par `[Authorize]`
- Soft delete pour Clients et Projets (données préservées)

---

## 🎨 Interface

- Sidebar sombre + contenu clair responsive
- Bilingue FR/AR avec direction RTL pour l'arabe
- Tableaux avec tri, recherche, filtres
- Fiches détaillées avec onglets (Info / Activités / Locaux / Historique)
- Modales de confirmation pour suppressions
- Alertes auto-disparaissantes
- Cascade gouvernorat → délégation en AJAX
- Compatible mobile / tablette / desktop
