using Microsoft.EntityFrameworkCore;
using ErpApp.Models;

namespace ErpApp.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Gouvernorat> Gouvernorats { get; set; }
        public DbSet<Delegation> Delegations { get; set; }
        public DbSet<Administration> Administrations { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Genre> Genres { get; set; }
        public DbSet<Agent> Agents { get; set; }
        public DbSet<Client> Clients { get; set; }
        public DbSet<Activite> Activites { get; set; }
        public DbSet<TypeProjet> TypeProjets { get; set; }
        public DbSet<TypeCreateur> TypeCreateurs { get; set; }
        public DbSet<TypeLocal> TypeLocaux { get; set; }
        public DbSet<Projet> Projets { get; set; }
        public DbSet<ProjetActivite> ProjetActivites { get; set; }
        public DbSet<Local> Locaux { get; set; }
        public DbSet<HistoriqueProjet> HistoriqueProjets { get; set; }
        public DbSet<Citoyen> Citoyens { get; set; }
        public DbSet<CitoyenProjet> CitoyenProjets { get; set; }
        public DbSet<CitoyenProjetActivite> CitoyenProjetActivites { get; set; }

        protected override void OnModelCreating(ModelBuilder m)
        {
            base.OnModelCreating(m);

            m.Entity<Gouvernorat>(e => {
                e.ToTable("Gouvernorats");
                e.HasIndex(x => x.NomFr).IsUnique();
                e.HasIndex(x => x.NomAr).IsUnique();
            });

            m.Entity<Delegation>(e => {
                e.ToTable("Delegations");
                e.HasIndex(x => new { x.NomFr, x.GouvernoratId }).IsUnique();
                e.HasIndex(x => new { x.NomAr, x.GouvernoratId }).IsUnique();
            });

            m.Entity<Administration>(e => {
                e.ToTable("Administrations");
                e.HasIndex(x => x.CodeAdministration).IsUnique();
            });

            m.Entity<Role>(e => {
                e.ToTable("Roles");
                e.HasIndex(x => x.LibelleFr).IsUnique();
                e.HasIndex(x => x.LibelleAr).IsUnique();
            });

            m.Entity<User>(e => {
                e.ToTable("Users");
                e.HasIndex(x => x.Login).IsUnique();
                e.HasIndex(x => x.Email).IsUnique();
                e.Ignore(x => x.Password);
                e.Ignore(x => x.ConfirmPassword);
            });

            m.Entity<Genre>(e => {
                e.ToTable("Genres");
                e.HasIndex(x => x.LibelleFr).IsUnique();
                e.HasIndex(x => x.LibelleAr).IsUnique();
            });

            m.Entity<Activite>(e => {
                e.ToTable("Activites");
                e.HasIndex(x => x.CodeNACE_Ape).IsUnique();
            });

            m.Entity<TypeProjet>(e => {
                e.ToTable("TypeProjets");
                e.HasIndex(x => x.LibelleFr).IsUnique();
                e.HasIndex(x => x.LibelleAr).IsUnique();
            });

            m.Entity<TypeCreateur>(e => {
                e.ToTable("TypeCreateur");
                e.HasIndex(x => x.LibelleFr).IsUnique();
                e.HasIndex(x => x.LibelleAr).IsUnique();
            });

            m.Entity<TypeLocal>(e => {
                e.ToTable("TypeLocaux");
                e.HasIndex(x => x.LibelleFr).IsUnique();
                e.HasIndex(x => x.LibelleAr).IsUnique();
            });

            m.Entity<Agent>(e => {
                e.ToTable("Agents");
                e.HasIndex(x => x.Matricule).IsUnique();
            });

            m.Entity<Client>(e => {
                e.ToTable("Clients");
                e.HasIndex(x => x.CIN).IsUnique();
                e.HasOne(x => x.Genre).WithMany(g => g.Clients).HasForeignKey(x => x.GenreId).OnDelete(DeleteBehavior.Restrict);
            });

            m.Entity<Projet>(e => {
                e.ToTable("Projets");
                e.HasIndex(x => x.NumeroProjet).IsUnique();
                e.HasIndex(x => x.MatriculeFiscale).IsUnique();
                e.HasIndex(x => x.RNE).IsUnique();
                e.HasOne(x => x.Client).WithMany(c => c.Projets).HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Restrict);
                e.HasOne(x => x.Gouvernorat).WithMany(g => g.Projets).HasForeignKey(x => x.GouvernoratId).OnDelete(DeleteBehavior.Restrict);
            });

            m.Entity<ProjetActivite>(e => {
                e.ToTable("ProjetActivites");
                e.HasKey(x => new { x.ProjetId, x.ActiviteId });
            });

            m.Entity<Local>(e => {
                e.ToTable("Locaux");
            });

            m.Entity<HistoriqueProjet>(e => {
                e.ToTable("HistoriqueProjets");
                e.HasKey(x => x.LogId);
                e.HasOne(x => x.Projet).WithMany(p => p.Historique).HasForeignKey(x => x.ProjetId).OnDelete(DeleteBehavior.Restrict);
                e.HasOne(x => x.ModifiePar).WithMany().HasForeignKey(x => x.ModifieById).OnDelete(DeleteBehavior.SetNull);
            });

            // ======= SEED DATA =======
            m.Entity<Genre>().HasData(
                new Genre { Id = 1, LibelleFr = "Homme", LibelleAr = "ذكر" },
                new Genre { Id = 2, LibelleFr = "Femme", LibelleAr = "أنثى" }
            );

            m.Entity<TypeCreateur>().HasData(
                new TypeCreateur { Id = 1, LibelleFr = "Personne Physique", LibelleAr = "شخص طبيعي" },
                new TypeCreateur { Id = 2, LibelleFr = "Personne Morale", LibelleAr = "شخص معنوي" }
            );

            m.Entity<TypeProjet>().HasData(
                new TypeProjet { Id = 1, LibelleFr = "Industriel", LibelleAr = "صناعي" },
                new TypeProjet { Id = 2, LibelleFr = "Commercial", LibelleAr = "تجاري" },
                new TypeProjet { Id = 3, LibelleFr = "Service", LibelleAr = "خدماتي" },
                new TypeProjet { Id = 4, LibelleFr = "Agricole", LibelleAr = "فلاحي" }
            );

            m.Entity<TypeLocal>().HasData(
                new TypeLocal { Id = 1, LibelleFr = "Bureau", LibelleAr = "مكتب" },
                new TypeLocal { Id = 2, LibelleFr = "Entrepôt", LibelleAr = "مستودع" },
                new TypeLocal { Id = 3, LibelleFr = "Local Commercial", LibelleAr = "محل تجاري" },
                new TypeLocal { Id = 4, LibelleFr = "Usine", LibelleAr = "مصنع" }
            );

            m.Entity<Gouvernorat>().HasData(
                new Gouvernorat { Id = 1, NomFr = "Tunis", NomAr = "تونس" },
                new Gouvernorat { Id = 2, NomFr = "Sfax", NomAr = "صفاقس" },
                new Gouvernorat { Id = 3, NomFr = "Sousse", NomAr = "سوسة" },
                new Gouvernorat { Id = 4, NomFr = "Nabeul", NomAr = "نابل" },
                new Gouvernorat { Id = 5, NomFr = "Bizerte", NomAr = "بنزرت" }
            );

            m.Entity<Role>().HasData(
                new Role { Id = 1, LibelleFr = "Administrateur", LibelleAr = "مدير النظام", Description = "Accès total au système" },
                new Role { Id = 2, LibelleFr = "Agent", LibelleAr = "عون", Description = "Gestion courante des dossiers" },
                new Role { Id = 3, LibelleFr = "Consultant", LibelleAr = "مستشار", Description = "Lecture seule" }
            );

            // Admin user (password: Admin@123)
            m.Entity<User>().HasData(
                new User {
                    Id = 1,
                    Login = "admin",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@123"),
                    Email = "admin@erp.tn",
                    RoleId = 1,
                    IsActive = true
                }
            );

            // Citoyen entities config
            m.Entity<Citoyen>(e => {
                e.ToTable("Citoyens");
                e.HasIndex(x => x.Login).IsUnique();
                e.HasIndex(x => x.Email).IsUnique();
                e.HasIndex(x => x.CIN).IsUnique();
            });
            m.Entity<CitoyenProjet>(e => {
                e.ToTable("CitoyenProjets");
                e.HasOne(x => x.Citoyen).WithMany(c => c.CitoyenProjets).HasForeignKey(x => x.CitoyenId).OnDelete(DeleteBehavior.Cascade);
            });
            m.Entity<CitoyenProjetActivite>(e => {
                e.ToTable("CitoyenProjetActivites");
                e.HasKey(x => new { x.CitoyenProjetId, x.ActiviteId });
            });
        }
    }
}
