using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ErpApp.Models
{
    public class Citoyen
    {
        public int Id { get; set; }
        [Required][MaxLength(100)][Display(Name="Nom")] public string Nom { get; set; } = "";
        [Required][MaxLength(100)][Display(Name="Prénom")] public string Prenom { get; set; } = "";
        [Required][MaxLength(20)][Display(Name="CIN")] public string CIN { get; set; } = "";
        [MaxLength(20)][Display(Name="Téléphone")] public string? Telephone { get; set; }
        [MaxLength(200)][Display(Name="Adresse")] public string? Adresse { get; set; }
        [Required][MaxLength(50)][Display(Name="Login")] public string Login { get; set; } = "";
        [Required][MaxLength(255)] public string PasswordHash { get; set; } = "";
        [Required][MaxLength(150)][EmailAddress][Display(Name="Email")] public string Email { get; set; } = "";
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime? LastLoginAt { get; set; }
        public string? ResetToken { get; set; }
        public DateTime? ResetTokenExpiry { get; set; }
        public ICollection<CitoyenProjet> CitoyenProjets { get; set; } = new List<CitoyenProjet>();
        [NotMapped] public string NomComplet => $"{Prenom} {Nom}";
    }

    public class CitoyenProjet
    {
        public int Id { get; set; }
        [Required] public int CitoyenId { get; set; }
        [ForeignKey("CitoyenId")] public Citoyen? Citoyen { get; set; }
        [Required][MaxLength(150)][Display(Name="Nom du projet")] public string NomProjet { get; set; } = "";
        [MaxLength(500)][Display(Name="Description")] public string? Description { get; set; }
        [Required][MaxLength(20)][Display(Name="Matricule Fiscale")] public string MatriculeFiscale { get; set; } = "";
        [Required][MaxLength(20)][Display(Name="RNE")] public string RNE { get; set; } = "";
        [MaxLength(200)][Display(Name="Adresse Sociale")] public string? AdresseSociale { get; set; }
        [Required][Display(Name="Type de projet")] public int TypeProjetId { get; set; }
        [ForeignKey("TypeProjetId")] public TypeProjet? TypeProjet { get; set; }
        [Required][Display(Name="Gouvernorat")] public int GouvernoratId { get; set; }
        [ForeignKey("GouvernoratId")] public Gouvernorat? Gouvernorat { get; set; }
        [Required][Display(Name="Type de créateur")] public int TypeCreateurId { get; set; }
        [ForeignKey("TypeCreateurId")] public TypeCreateur? TypeCreateur { get; set; }
        [MaxLength(20)] public string Statut { get; set; } = "EnAttente";
        public string? CommentaireAdmin { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime? UpdatedAt { get; set; }
        public ICollection<CitoyenProjetActivite> Activites { get; set; } = new List<CitoyenProjetActivite>();
    }

    public class CitoyenProjetActivite
    {
        public int CitoyenProjetId { get; set; }
        [ForeignKey("CitoyenProjetId")] public CitoyenProjet? CitoyenProjet { get; set; }
        public int ActiviteId { get; set; }
        [ForeignKey("ActiviteId")] public Activite? Activite { get; set; }
        public bool EstPrincipale { get; set; } = false;
    }

    public class RegisterCitoyenViewModel
    {
        [Required][MaxLength(100)][Display(Name="Nom")] public string Nom { get; set; } = "";
        [Required][MaxLength(100)][Display(Name="Prénom")] public string Prenom { get; set; } = "";
        [Required][MaxLength(20)][Display(Name="CIN")] public string CIN { get; set; } = "";
        [MaxLength(20)][Display(Name="Téléphone")] public string? Telephone { get; set; }
        [MaxLength(200)][Display(Name="Adresse")] public string? Adresse { get; set; }
        [Required][MaxLength(50)][Display(Name="Login")] public string Login { get; set; } = "";
        [Required][EmailAddress][Display(Name="Email")] public string Email { get; set; } = "";
        [Required][MinLength(6)][DataType(DataType.Password)][Display(Name="Mot de passe")] public string Password { get; set; } = "";
        [Required][DataType(DataType.Password)][Compare("Password", ErrorMessage="Les mots de passe ne correspondent pas.")][Display(Name="Confirmer")] public string ConfirmPassword { get; set; } = "";
    }

    public class ForgotPasswordViewModel
    {
        [Required][Display(Name="Login ou Email")] public string LoginOrEmail { get; set; } = "";
        [Required][MaxLength(20)][Display(Name="CIN (vérification identité)")] public string CIN { get; set; } = "";
    }

    public class ResetPasswordViewModel
    {
        [Required] public string Token { get; set; } = "";
        [Required][MinLength(6)][DataType(DataType.Password)][Display(Name="Nouveau mot de passe")] public string NewPassword { get; set; } = "";
        [Required][DataType(DataType.Password)][Compare("NewPassword", ErrorMessage="Les mots de passe ne correspondent pas.")][Display(Name="Confirmer")] public string ConfirmPassword { get; set; } = "";
    }

    public class CitoyenProjetViewModel
    {
        public CitoyenProjet Projet { get; set; } = new();
        public List<int> ActiviteIds { get; set; } = new();
        public int? PrincipaleActiviteId { get; set; }
    }

    public class CitoyenDashboardViewModel
    {
        public Citoyen Citoyen { get; set; } = new();
        public int TotalProjets { get; set; }
        public int ProjetsEnAttente { get; set; }
        public int ProjetsValides { get; set; }
        public int ProjetsRejetes { get; set; }
        public List<CitoyenProjet> DerniersProjets { get; set; } = new();
    }
}
