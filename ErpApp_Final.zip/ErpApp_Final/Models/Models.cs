using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ErpApp.Models
{
    // =====================================================================
    // GEOGRAPHY
    // =====================================================================
    public class Gouvernorat
    {
        public int Id { get; set; }
        [Required][MaxLength(100)][Display(Name = "Nom (FR)")] public string NomFr { get; set; } = "";
        [Required][MaxLength(100)][Display(Name = "الاسم (عربي)")] public string NomAr { get; set; } = "";
        public ICollection<Delegation> Delegations { get; set; } = new List<Delegation>();
        public ICollection<Administration> Administrations { get; set; } = new List<Administration>();
        public ICollection<Projet> Projets { get; set; } = new List<Projet>();
    }

    public class Delegation
    {
        public int Id { get; set; }
        [Required][MaxLength(100)][Display(Name = "Nom (FR)")] public string NomFr { get; set; } = "";
        [Required][MaxLength(100)][Display(Name = "الاسم (عربي)")] public string NomAr { get; set; } = "";
        [Required][Display(Name = "Gouvernorat")] public int GouvernoratId { get; set; }
        [ForeignKey("GouvernoratId")] public Gouvernorat? Gouvernorat { get; set; }
        [Required][MaxLength(10)][Display(Name = "Code Postal")] public string CodePostal { get; set; } = "";
    }

    public class Administration
    {
        public int Id { get; set; }
        [Required][MaxLength(150)][Display(Name = "Nom (FR)")] public string NomFr { get; set; } = "";
        [Required][MaxLength(150)][Display(Name = "الاسم (عربي)")] public string NomAr { get; set; } = "";
        [Required][Display(Name = "Gouvernorat")] public int GouvernoratId { get; set; }
        [ForeignKey("GouvernoratId")] public Gouvernorat? Gouvernorat { get; set; }
        [Required][MaxLength(20)][Display(Name = "Code Administration")] public string CodeAdministration { get; set; } = "";
        public ICollection<Agent> Agents { get; set; } = new List<Agent>();
    }

    // =====================================================================
    // SECURITY & RBAC
    // =====================================================================
    public class Role
    {
        public int Id { get; set; }
        [Required][MaxLength(50)][Display(Name = "Libellé (FR)")] public string LibelleFr { get; set; } = "";
        [Required][MaxLength(50)][Display(Name = "التسمية (عربي)")] public string LibelleAr { get; set; } = "";
        [MaxLength(250)][Display(Name = "Description")] public string? Description { get; set; }
        public ICollection<User> Users { get; set; } = new List<User>();
    }

    public class User
    {
        public int Id { get; set; }
        [Required][MaxLength(50)][Display(Name = "Login")] public string Login { get; set; } = "";
        [Required][MaxLength(255)] public string PasswordHash { get; set; } = "";
        [Required][MaxLength(150)][EmailAddress][Display(Name = "Email")] public string Email { get; set; } = "";
        [Required][Display(Name = "Rôle")] public int RoleId { get; set; }
        [ForeignKey("RoleId")] public Role? Role { get; set; }
        [Display(Name = "Actif")] public bool IsActive { get; set; } = true;
        public DateTime? LastLoginAt { get; set; }
        public int FailedAttempts { get; set; } = 0;
        [Display(Name = "Verrouillé")] public bool IsLocked { get; set; } = false;
        public DateTime? LockedUntil { get; set; }
        [NotMapped][DataType(DataType.Password)][Display(Name = "Mot de passe")] public string? Password { get; set; }
        [NotMapped][DataType(DataType.Password)][Display(Name = "Confirmer")] public string? ConfirmPassword { get; set; }
    }

    // =====================================================================
    // REFERENCE DATA
    // =====================================================================
    public class Genre
    {
        public int Id { get; set; }
        [Required][MaxLength(20)][Display(Name = "Libellé (FR)")] public string LibelleFr { get; set; } = "";
        [Required][MaxLength(20)][Display(Name = "التسمية (عربي)")] public string LibelleAr { get; set; } = "";
        public ICollection<Client> Clients { get; set; } = new List<Client>();
    }

    public class Activite
    {
        public int Id { get; set; }
        [Required][MaxLength(10)][Display(Name = "Code NACE/APE")] public string CodeNACE_Ape { get; set; } = "";
        [Required][MaxLength(150)][Display(Name = "Libellé (FR)")] public string LibelleFr { get; set; } = "";
        [Required][MaxLength(150)][Display(Name = "التسمية (عربي)")] public string LibelleAr { get; set; } = "";
    }

    public class TypeProjet
    {
        public int Id { get; set; }
        [Required][MaxLength(50)][Display(Name = "Libellé (FR)")] public string LibelleFr { get; set; } = "";
        [Required][MaxLength(50)][Display(Name = "التسمية (عربي)")] public string LibelleAr { get; set; } = "";
        public ICollection<Projet> Projets { get; set; } = new List<Projet>();
    }

    public class TypeCreateur
    {
        public int Id { get; set; }
        [Required][MaxLength(50)][Display(Name = "Libellé (FR)")] public string LibelleFr { get; set; } = "";
        [Required][MaxLength(50)][Display(Name = "التسمية (عربي)")] public string LibelleAr { get; set; } = "";
        public ICollection<Projet> Projets { get; set; } = new List<Projet>();
    }

    public class TypeLocal
    {
        public int Id { get; set; }
        [Required][MaxLength(50)][Display(Name = "Libellé (FR)")] public string LibelleFr { get; set; } = "";
        [Required][MaxLength(50)][Display(Name = "التسمية (عربي)")] public string LibelleAr { get; set; } = "";
        public ICollection<Local> Locaux { get; set; } = new List<Local>();
    }

    // =====================================================================
    // AGENTS & CLIENTS
    // =====================================================================
    public class Agent
    {
        public int Id { get; set; }
        [Required][MaxLength(15)][Display(Name = "Matricule")] public string Matricule { get; set; } = "";
        [Required][MaxLength(100)][Display(Name = "Nom")] public string Nom { get; set; } = "";
        [Required][MaxLength(100)][Display(Name = "Prénom")] public string Prenom { get; set; } = "";
        [Required][Display(Name = "Administration")] public int AdministrationId { get; set; }
        [ForeignKey("AdministrationId")] public Administration? Administration { get; set; }
        [Display(Name = "Utilisateur")] public int? UserId { get; set; }
        [ForeignKey("UserId")] public User? User { get; set; }
        [MaxLength(20)][Display(Name = "Tél. Professionnel")] public string? TelephoneProfessionnel { get; set; }
        [NotMapped] public string NomComplet => $"{Prenom} {Nom}";
    }

    public class Client
    {
        public int Id { get; set; }
        [Required][MaxLength(100)][Display(Name = "Nom")] public string Nom { get; set; } = "";
        [Required][MaxLength(100)][Display(Name = "Prénom")] public string Prenom { get; set; } = "";
        [Required][Display(Name = "Genre")] public int GenreId { get; set; }
        [ForeignKey("GenreId")] public Genre? Genre { get; set; }
        [MaxLength(100)][Display(Name = "Nom du père")] public string? NomPere { get; set; }
        [MaxLength(100)][Display(Name = "Nom du grand-père")] public string? NomGrandPere { get; set; }
        [MaxLength(100)][Display(Name = "Nom de la mère")] public string? NomMere { get; set; }
        [DataType(DataType.Date)][Display(Name = "Date de naissance")] public DateTime? DateNaissance { get; set; }
        [MaxLength(150)][Display(Name = "Lieu de naissance")] public string? LieuNaissance { get; set; }
        [Required][MaxLength(20)][Display(Name = "CIN")] public string CIN { get; set; } = "";
        [MaxLength(20)][Display(Name = "Téléphone")] public string? Telephone { get; set; }
        [MaxLength(200)][Display(Name = "Adresse")] public string? Adresse { get; set; }
        public int? UserId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public int CreatedById { get; set; } = 1;
        public DateTime? UpdatedAt { get; set; }
        public int? UpdatedById { get; set; }
        [Display(Name = "Conditions acceptées")] public bool AcceptConditions { get; set; } = true;
        public bool IsDeleted { get; set; } = false;
        public DateTime? DeletedAt { get; set; }
        public int? DeletedById { get; set; }
        public ICollection<Projet> Projets { get; set; } = new List<Projet>();
        [NotMapped] public string NomComplet => $"{Prenom} {Nom}";
        [NotMapped] public int? Age => DateNaissance.HasValue ? (int)((DateTime.Now - DateNaissance.Value).TotalDays / 365.25) : null;
    }

    // =====================================================================
    // PROJETS (CORE BUSINESS)
    // =====================================================================
    public class Projet
    {
        public int Id { get; set; }
        [MaxLength(30)][Display(Name = "N° Projet")] public string? NumeroProjet { get; set; }
        [Required][Display(Name = "Client")] public int ClientId { get; set; }
        [ForeignKey("ClientId")] public Client? Client { get; set; }
        [Required][Display(Name = "Gouvernorat")] public int GouvernoratId { get; set; }
        [ForeignKey("GouvernoratId")] public Gouvernorat? Gouvernorat { get; set; }
        [Required][Display(Name = "Type de projet")] public int TypeProjetId { get; set; }
        [ForeignKey("TypeProjetId")] public TypeProjet? TypeProjet { get; set; }
        [Required][Display(Name = "Type de créateur")] public int TypeCreateurId { get; set; }
        [ForeignKey("TypeCreateurId")] public TypeCreateur? TypeCreateur { get; set; }
        [Required][MaxLength(150)][Display(Name = "Nom du projet")] public string NomProjet { get; set; } = "";
        [MaxLength(500)][Display(Name = "Description")] public string? Description { get; set; }
        [Required][MaxLength(20)][Display(Name = "Matricule Fiscale")] public string MatriculeFiscale { get; set; } = "";
        [Required][MaxLength(20)][Display(Name = "RNE")] public string RNE { get; set; } = "";
        [MaxLength(200)][Display(Name = "Adresse Sociale")] public string? AdresseSociale { get; set; }
        [Display(Name = "Actif")] public bool EstActif { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public int CreatedById { get; set; } = 1;
        public DateTime? UpdatedAt { get; set; }
        public int? UpdatedById { get; set; }
        public bool IsDeleted { get; set; } = false;
        public DateTime? DeletedAt { get; set; }
        public int? DeletedById { get; set; }
        public ICollection<ProjetActivite> ProjetActivites { get; set; } = new List<ProjetActivite>();
        public ICollection<Local> Locaux { get; set; } = new List<Local>();
        public ICollection<HistoriqueProjet> Historique { get; set; } = new List<HistoriqueProjet>();
    }

    public class ProjetActivite
    {
        public int ProjetId { get; set; }
        [ForeignKey("ProjetId")] public Projet? Projet { get; set; }
        public int ActiviteId { get; set; }
        [ForeignKey("ActiviteId")] public Activite? Activite { get; set; }
        [Display(Name = "Activité principale")] public bool EstPrincipale { get; set; } = false;
    }

    public class Local
    {
        public int Id { get; set; }
        [Required][Display(Name = "Projet")] public int ProjetId { get; set; }
        [ForeignKey("ProjetId")] public Projet? Projet { get; set; }
        [Required][Display(Name = "Type de local")] public int TypeLocalId { get; set; }
        [ForeignKey("TypeLocalId")] public TypeLocal? TypeLocal { get; set; }
        [Required][Display(Name = "Délégation")] public int DelegationId { get; set; }
        [ForeignKey("DelegationId")] public Delegation? Delegation { get; set; }
        [Required][MaxLength(200)][Display(Name = "Adresse")] public string Adresse { get; set; } = "";
        [Required][Display(Name = "Surface (m²)")][Range(0.01, double.MaxValue, ErrorMessage = "La surface doit être positive")] public decimal Surface { get; set; }
    }

    public class HistoriqueProjet
    {
        public int LogId { get; set; }
        public int ProjetId { get; set; }
        [ForeignKey("ProjetId")] public Projet? Projet { get; set; }
        public string? AncienNumeroProjet { get; set; }
        public int AncienClientId { get; set; }
        public int AncienGouvernoratId { get; set; }
        public int AncienTypeProjetId { get; set; }
        public int AncienTypeCreateurId { get; set; }
        public string AncienNomProjet { get; set; } = "";
        public string? AncienneDescription { get; set; }
        public string AncienneMatriculeFiscale { get; set; } = "";
        public string AncienRNE { get; set; } = "";
        public string? AncienneAdresseSociale { get; set; }
        public bool AncienEstActif { get; set; }
        public DateTime AncienCreatedAt { get; set; }
        public int AncienCreatedById { get; set; }
        public DateTime? AncienUpdatedAt { get; set; }
        public int? AncienUpdatedById { get; set; }
        public DateTime DateModification { get; set; } = DateTime.Now;
        public int? ModifieById { get; set; }
        [ForeignKey("ModifieById")] public User? ModifiePar { get; set; }
    }

    // =====================================================================
    // VIEW MODELS
    // =====================================================================
    public class DashboardViewModel
    {
        public int TotalClients { get; set; }
        public int TotalProjets { get; set; }
        public int TotalAgents { get; set; }
        public int ProjetsActifs { get; set; }
        public int ProjetsInactifs { get; set; }
        public int NouveauxClientsMois { get; set; }
        public int NouveauxProjetsMois { get; set; }
        public List<Projet> DerniersProjets { get; set; } = new();
        public List<Client> DerniersClients { get; set; } = new();
        public Dictionary<string, int> ProjetsByType { get; set; } = new();
        public Dictionary<string, int> ProjetsByGouvernorat { get; set; } = new();
    }

    public class ProjetViewModel
    {
        public Projet Projet { get; set; } = new();
        public List<int> ActiviteIds { get; set; } = new();
        public bool HasPrincipaleActivite { get; set; }
        public int? PrincipaleActiviteId { get; set; }
    }

    public class LoginViewModel
    {
        [Required][Display(Name = "Login")] public string Login { get; set; } = "";
        [Required][DataType(DataType.Password)][Display(Name = "Mot de passe")] public string Password { get; set; } = "";
    }
}
